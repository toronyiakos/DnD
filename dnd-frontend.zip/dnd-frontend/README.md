# Realm Codex – D&D 5e Frontend

A dark fantasy-themed React frontend for a D&D 5th Edition online platform.

## Tech Stack

- **React 18** + **Vite** – Fast dev server and build
- **React Router v6** – Client-side routing with `createBrowserRouter`
- **Zustand** – Lightweight auth state management
- **Axios** – HTTP client with JWT interceptor
- **TailwindCSS** – Utility-first styling with custom dark RPG theme
- **Google Fonts** – Cinzel (headings) + Crimson Text (body)

## Quick Start

```bash
# Install dependencies
npm install

# Set API URL (optional, defaults to http://localhost:5000)
# Edit .env file if your backend is on a different port

# Start development server
npm run dev
```

The app runs on `http://localhost:3000` with an API proxy to your backend.

## Project Structure

```
src/
├── api/              # Axios instance + endpoint functions
├── context/          # Zustand auth store
├── hooks/            # Custom React hooks for data fetching
├── pages/            # Route-level page components
├── components/
│   ├── layout/       # Navbar, ProtectedRoute, MainLayout
│   ├── character/    # CharacterCard, CharacterSheet, Wizard, Skills, Inventory
│   ├── spell/        # SpellCard, SpellFilter, SpellFormModal
│   ├── map/          # BattleMap with drag & drop
│   ├── admin/        # (admin-specific components)
│   └── ui/           # LoadingSpinner, ErrorMessage, Modal, ConfirmDialog
└── App.jsx           # Router configuration
```

## Features

### Authentication
- Login / Register with JWT tokens
- Token stored in localStorage with expiration checking
- Axios interceptor auto-attaches Bearer token
- Protected routes redirect to `/login`
- Role-based UI rendering (user / game_master / admin)

### Characters (`/characters`)
- Character list with summary cards (HP bar, level, class, race)
- Multi-step character creation wizard (5 steps):
  1. Name & description
  2. Race, background, alignment, size
  3. Class, subclass, level
  4. Ability scores (Point Buy / 4d6 Drop Lowest / 3d6)
  5. HP, AC, speed, hit dice, gold, languages
- Detailed character sheet (`/characters/:id`):
  - Full ability scores with modifier calculation
  - Skills list with proficiency/expertise indicators
  - HP management (damage/heal buttons)
  - Inventory tab with item add/remove
  - Spells tab showing class spells grouped by level

### Spell Compendium (`/spells`)
- Filterable spell list (level, school, class)
- Spell cards with all details
- Grouped by spell level with color-coded borders
- GM+: Create/edit spells via modal form
- Admin: Delete spells

### Battlemap (`/map`)
- Grid-based tactical map (20×14 grid)
- Drag & drop tokens
- Double-click to place new tokens
- Color-coded by type (player/monster/NPC)
- Click to select, delete tokens

### Admin Panel (`/admin`)
- User list table
- Role management (user / game_master / admin)
- User deletion with confirmation

## Visual Theme

- **Dark RPG** aesthetic with obsidian backgrounds
- **Gold** accent colors for headings and interactive elements
- **Blood red** for destructive actions and danger states
- **Parchment** tones for text and content areas
- Custom card styling with subtle gold border glow
- Ornamental dividers between sections
- Fantasy fonts (Cinzel + Crimson Text)

## Environment Variables

| Variable | Default | Description |
|----------|---------|-------------|
| `VITE_API_BASE_URL` | `http://localhost:5000` | Backend API base URL |

## Backend Requirements

This frontend expects an ASP.NET Core 8 REST API at the configured URL.
See the API specification document for all endpoints.
