import { useState, useRef, useCallback, useEffect } from 'react';

const CELL_SIZE = 50;
const DEFAULT_GRID_W = 20;
const DEFAULT_GRID_H = 14;

export default function BattleMap() {
  const [tokens, setTokens] = useState([
    // Demo tokens for when no backend is available
    { id: 1, name: 'Fighter', x: 3, y: 2, color: '#d4a024', type: 'player' },
    { id: 2, name: 'Wizard', x: 5, y: 4, color: '#6366f1', type: 'player' },
    { id: 3, name: 'Goblin', x: 10, y: 6, color: '#c62828', type: 'monster' },
    { id: 4, name: 'Goblin', x: 11, y: 5, color: '#c62828', type: 'monster' },
    { id: 5, name: 'Orc', x: 14, y: 8, color: '#991b1b', type: 'monster' },
  ]);
  const [dragging, setDragging] = useState(null);
  const [dragOffset, setDragOffset] = useState({ x: 0, y: 0 });
  const [dragPos, setDragPos] = useState({ x: 0, y: 0 });
  const [selectedToken, setSelectedToken] = useState(null);
  const [showAddToken, setShowAddToken] = useState(false);
  const [newTokenName, setNewTokenName] = useState('');
  const [newTokenType, setNewTokenType] = useState('player');
  const [addPos, setAddPos] = useState({ x: 0, y: 0 });
  const mapRef = useRef(null);

  const gridWidth = DEFAULT_GRID_W;
  const gridHeight = DEFAULT_GRID_H;

  const getGridPos = useCallback(
    (clientX, clientY) => {
      if (!mapRef.current) return { x: 0, y: 0 };
      const rect = mapRef.current.getBoundingClientRect();
      const x = Math.floor((clientX - rect.left) / CELL_SIZE);
      const y = Math.floor((clientY - rect.top) / CELL_SIZE);
      return {
        x: Math.max(0, Math.min(gridWidth - 1, x)),
        y: Math.max(0, Math.min(gridHeight - 1, y)),
      };
    },
    [gridWidth, gridHeight]
  );

  const handleMouseDown = (e, token) => {
    e.preventDefault();
    e.stopPropagation();
    setDragging(token.id);
    setSelectedToken(token.id);
    const rect = mapRef.current.getBoundingClientRect();
    setDragOffset({
      x: e.clientX - rect.left - token.x * CELL_SIZE,
      y: e.clientY - rect.top - token.y * CELL_SIZE,
    });
    setDragPos({ x: e.clientX, y: e.clientY });
  };

  const handleMouseMove = useCallback(
    (e) => {
      if (dragging === null) return;
      setDragPos({ x: e.clientX, y: e.clientY });
    },
    [dragging]
  );

  const handleMouseUp = useCallback(
    (e) => {
      if (dragging === null) return;
      const pos = getGridPos(e.clientX, e.clientY);
      setTokens((prev) =>
        prev.map((t) => (t.id === dragging ? { ...t, x: pos.x, y: pos.y } : t))
      );
      setDragging(null);
    },
    [dragging, getGridPos]
  );

  useEffect(() => {
    if (dragging !== null) {
      window.addEventListener('mousemove', handleMouseMove);
      window.addEventListener('mouseup', handleMouseUp);
      return () => {
        window.removeEventListener('mousemove', handleMouseMove);
        window.removeEventListener('mouseup', handleMouseUp);
      };
    }
  }, [dragging, handleMouseMove, handleMouseUp]);

  const handleMapClick = (e) => {
    if (dragging !== null) return;
    setSelectedToken(null);
  };

  const handleMapDoubleClick = (e) => {
    const pos = getGridPos(e.clientX, e.clientY);
    setAddPos(pos);
    setShowAddToken(true);
  };

  const handleAddToken = () => {
    if (!newTokenName.trim()) return;
    const colors = {
      player: '#d4a024',
      monster: '#c62828',
      npc: '#2e7d32',
    };
    const newToken = {
      id: Date.now(),
      name: newTokenName.trim(),
      x: addPos.x,
      y: addPos.y,
      color: colors[newTokenType] || '#d4a024',
      type: newTokenType,
    };
    setTokens((prev) => [...prev, newToken]);
    setNewTokenName('');
    setShowAddToken(false);
  };

  const handleDeleteToken = (id) => {
    setTokens((prev) => prev.filter((t) => t.id !== id));
    setSelectedToken(null);
  };

  return (
    <div className="space-y-4">
      {/* Toolbar */}
      <div className="card-parchment p-3 flex items-center justify-between flex-wrap gap-2">
        <p className="text-xs font-cinzel text-obsidian-300 uppercase tracking-wider">
          Double-click to add token • Drag tokens to move
        </p>
        {selectedToken && (
          <div className="flex items-center gap-2">
            <span className="text-sm text-parchment-200">
              {tokens.find((t) => t.id === selectedToken)?.name}
            </span>
            <button
              onClick={() => handleDeleteToken(selectedToken)}
              className="btn-ghost text-xs py-1 px-2 text-blood-400 border-blood-600/40"
            >
              Remove
            </button>
          </div>
        )}
      </div>

      {/* Map container */}
      <div className="overflow-auto rounded-lg border border-obsidian-600/40">
        <div
          ref={mapRef}
          className="relative grid-overlay cursor-crosshair select-none"
          style={{
            width: gridWidth * CELL_SIZE,
            height: gridHeight * CELL_SIZE,
            background:
              'linear-gradient(145deg, #1a1a20 0%, #1f1f26 30%, #1a1a20 60%, #16161b 100%)',
          }}
          onClick={handleMapClick}
          onDoubleClick={handleMapDoubleClick}
        >
          {/* Coordinate labels - rows */}
          {Array.from({ length: gridHeight }, (_, y) => (
            <div
              key={`row-${y}`}
              className="absolute text-[8px] text-obsidian-400 font-cinzel pointer-events-none"
              style={{ left: 2, top: y * CELL_SIZE + 2 }}
            >
              {y + 1}
            </div>
          ))}

          {/* Coordinate labels - cols */}
          {Array.from({ length: gridWidth }, (_, x) => (
            <div
              key={`col-${x}`}
              className="absolute text-[8px] text-obsidian-400 font-cinzel pointer-events-none"
              style={{ left: x * CELL_SIZE + 2, top: 2 }}
            >
              {String.fromCharCode(65 + (x % 26))}
            </div>
          ))}

          {/* Tokens */}
          {tokens.map((token) => {
            const isDragging = dragging === token.id;
            let posX = token.x * CELL_SIZE;
            let posY = token.y * CELL_SIZE;

            if (isDragging && mapRef.current) {
              const rect = mapRef.current.getBoundingClientRect();
              posX = dragPos.x - rect.left - dragOffset.x;
              posY = dragPos.y - rect.top - dragOffset.y;
            }

            return (
              <div
                key={token.id}
                className={`absolute flex items-center justify-center rounded-full cursor-grab active:cursor-grabbing select-none transition-shadow ${
                  selectedToken === token.id
                    ? 'ring-2 ring-gold-400 ring-offset-1 ring-offset-obsidian-900'
                    : ''
                } ${isDragging ? 'z-50 opacity-80' : 'z-10'}`}
                style={{
                  left: posX + 4,
                  top: posY + 4,
                  width: CELL_SIZE - 8,
                  height: CELL_SIZE - 8,
                  backgroundColor: token.color,
                  boxShadow: `0 2px 8px ${token.color}44`,
                  transition: isDragging ? 'none' : 'left 0.15s ease, top 0.15s ease',
                }}
                onMouseDown={(e) => handleMouseDown(e, token)}
                title={token.name}
              >
                <span className="text-[10px] font-cinzel font-bold text-white drop-shadow-md select-none leading-none text-center">
                  {token.name.substring(0, 2).toUpperCase()}
                </span>
              </div>
            );
          })}
        </div>
      </div>

      {/* Add Token Mini-Modal */}
      {showAddToken && (
        <div className="card-parchment p-4 max-w-sm mx-auto">
          <h4 className="text-sm font-cinzel font-bold text-gold-400 mb-3">
            Add Token at ({String.fromCharCode(65 + addPos.x)}{addPos.y + 1})
          </h4>
          <div className="space-y-3">
            <input
              type="text"
              value={newTokenName}
              onChange={(e) => setNewTokenName(e.target.value)}
              className="input-field text-sm py-2"
              placeholder="Token name..."
              autoFocus
              onKeyDown={(e) => e.key === 'Enter' && handleAddToken()}
            />
            <select
              value={newTokenType}
              onChange={(e) => setNewTokenType(e.target.value)}
              className="select-field text-sm py-2"
            >
              <option value="player">Player (Gold)</option>
              <option value="monster">Monster (Red)</option>
              <option value="npc">NPC (Green)</option>
            </select>
            <div className="flex justify-end gap-2">
              <button onClick={() => setShowAddToken(false)} className="btn-ghost text-xs py-1.5">
                Cancel
              </button>
              <button onClick={handleAddToken} className="btn-gold text-xs py-1.5">
                Place Token
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
