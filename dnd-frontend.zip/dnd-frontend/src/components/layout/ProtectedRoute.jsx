import { Navigate, Outlet } from 'react-router-dom';
import useAuthStore from '../../context/AuthContext';

export default function ProtectedRoute({ requiredRole }) {
  const token = useAuthStore((s) => s.token);
  const role = useAuthStore((s) => s.role);
  const expiresAt = useAuthStore((s) => s.expiresAt);

  // Not logged in
  if (!token) {
    return <Navigate to="/login" replace />;
  }

  // Token expired
  if (expiresAt && new Date(expiresAt) < new Date()) {
    useAuthStore.getState().logout();
    return <Navigate to="/login" replace />;
  }

  // Role check
  if (requiredRole === 'admin' && role !== 'admin') {
    return <Navigate to="/characters" replace />;
  }

  if (requiredRole === 'game_master' && role !== 'game_master' && role !== 'admin') {
    return <Navigate to="/characters" replace />;
  }

  return <Outlet />;
}
