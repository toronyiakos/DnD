import { useState } from 'react';
import { Link, NavLink, useNavigate } from 'react-router-dom';
import useAuthStore from '../../context/AuthContext';

const navLinkClass = ({ isActive }) =>
  `px-3 py-2 rounded-md text-sm font-cinzel tracking-wider uppercase transition-all duration-200 ${
    isActive
      ? 'text-gold-400 bg-gold-400/10'
      : 'text-parchment-300 hover:text-gold-300 hover:bg-obsidian-600'
  }`;

export default function Navbar() {
  const { user, role, logout } = useAuthStore();
  const navigate = useNavigate();
  const [mobileOpen, setMobileOpen] = useState(false);

  const handleLogout = () => {
    logout();
    navigate('/login');
  };

  const isGM = role === 'game_master' || role === 'admin';
  const isAdmin = role === 'admin';

  return (
    <nav className="sticky top-0 z-40 border-b border-obsidian-600/60 bg-obsidian-900/95 backdrop-blur-md">
      <div className="max-w-7xl mx-auto px-4 sm:px-6">
        <div className="flex items-center justify-between h-16">
          {/* Logo */}
          <Link to="/characters" className="flex items-center gap-2 group">
            <svg className="w-7 h-7 text-gold-500 group-hover:text-gold-400 transition-colors" viewBox="0 0 24 24" fill="currentColor">
              <path d="M12 2L2 7l10 5 10-5-10-5zM2 17l10 5 10-5M2 12l10 5 10-5" stroke="currentColor" strokeWidth="1" fill="none"/>
            </svg>
            <span className="text-lg font-cinzel font-bold text-gold-400 group-hover:text-gold-300 transition-colors tracking-wider hidden sm:block">
              Realm Codex
            </span>
          </Link>

          {/* Desktop nav */}
          <div className="hidden md:flex items-center gap-1">
            <NavLink to="/characters" className={navLinkClass}>
              Characters
            </NavLink>
            <NavLink to="/spells" className={navLinkClass}>
              Spells
            </NavLink>
            <NavLink to="/map" className={navLinkClass}>
              Battlemap
            </NavLink>
            {isAdmin && (
              <NavLink to="/admin" className={navLinkClass}>
                Admin
              </NavLink>
            )}
          </div>

          {/* User section */}
          <div className="hidden md:flex items-center gap-4">
            <div className="text-right">
              <p className="text-sm font-cinzel text-parchment-200">{user}</p>
              <p className="text-[10px] font-cinzel uppercase tracking-[0.2em] text-gold-600">
                {role === 'game_master' ? 'Game Master' : role}
              </p>
            </div>
            <button onClick={handleLogout} className="btn-ghost text-xs py-1.5 px-3">
              Logout
            </button>
          </div>

          {/* Mobile hamburger */}
          <button
            onClick={() => setMobileOpen(!mobileOpen)}
            className="md:hidden text-parchment-300 hover:text-gold-400 transition-colors"
          >
            <svg className="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              {mobileOpen ? (
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
              ) : (
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6h16M4 12h16M4 18h16" />
              )}
            </svg>
          </button>
        </div>

        {/* Mobile menu */}
        {mobileOpen && (
          <div className="md:hidden border-t border-obsidian-600/40 pb-4 pt-2 space-y-1">
            <NavLink to="/characters" className={navLinkClass} onClick={() => setMobileOpen(false)}>
              Characters
            </NavLink>
            <NavLink to="/spells" className={navLinkClass} onClick={() => setMobileOpen(false)}>
              Spells
            </NavLink>
            <NavLink to="/map" className={navLinkClass} onClick={() => setMobileOpen(false)}>
              Battlemap
            </NavLink>
            {isAdmin && (
              <NavLink to="/admin" className={navLinkClass} onClick={() => setMobileOpen(false)}>
                Admin
              </NavLink>
            )}
            <div className="pt-3 border-t border-obsidian-600/40 mt-3 flex items-center justify-between px-3">
              <div>
                <p className="text-sm font-cinzel text-parchment-200">{user}</p>
                <p className="text-[10px] font-cinzel uppercase tracking-[0.2em] text-gold-600">
                  {role === 'game_master' ? 'Game Master' : role}
                </p>
              </div>
              <button onClick={handleLogout} className="btn-ghost text-xs py-1.5 px-3">
                Logout
              </button>
            </div>
          </div>
        )}
      </div>
    </nav>
  );
}
