import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { charactersApi } from '../../api/characters';
import { useReferenceData, useSubclasses } from '../../hooks/useReferenceData';
import LoadingSpinner from '../ui/LoadingSpinner';

const STEPS = ['Basics', 'Race & Background', 'Class', 'Abilities', 'Combat & Details'];

function StepIndicator({ current, steps }) {
  return (
    <div className="flex items-center justify-center gap-2 mb-8">
      {steps.map((step, i) => (
        <div key={step} className="flex items-center gap-2">
          <div
            className={`w-8 h-8 rounded-full flex items-center justify-center text-xs font-cinzel font-bold border-2 transition-all duration-300 ${
              i < current
                ? 'bg-gold-600 border-gold-500 text-obsidian-900'
                : i === current
                ? 'bg-gold-500/20 border-gold-400 text-gold-400'
                : 'bg-obsidian-700 border-obsidian-500 text-obsidian-300'
            }`}
          >
            {i < current ? '✓' : i + 1}
          </div>
          {i < steps.length - 1 && (
            <div
              className={`hidden sm:block w-8 h-0.5 ${
                i < current ? 'bg-gold-600' : 'bg-obsidian-600'
              }`}
            />
          )}
        </div>
      ))}
    </div>
  );
}

// Dice rolling helper
function roll3d6() {
  return Array.from({ length: 3 }, () => Math.floor(Math.random() * 6) + 1).reduce((a, b) => a + b, 0);
}

function roll4d6DropLowest() {
  const rolls = Array.from({ length: 4 }, () => Math.floor(Math.random() * 6) + 1);
  rolls.sort((a, b) => a - b);
  return rolls.slice(1).reduce((a, b) => a + b, 0);
}

const ABILITY_NAMES = ['strength', 'dexterity', 'constitution', 'intelligence', 'wisdom', 'charisma'];
const ABILITY_LABELS = { strength: 'STR', dexterity: 'DEX', constitution: 'CON', intelligence: 'INT', wisdom: 'WIS', charisma: 'CHA' };

const POINT_BUY_COSTS = { 8: 0, 9: 1, 10: 2, 11: 3, 12: 4, 13: 5, 14: 7, 15: 9 };
const POINT_BUY_TOTAL = 27;

export default function CharacterWizard() {
  const navigate = useNavigate();
  const { races, classes, backgrounds, alignments, sizes, loading: refLoading } = useReferenceData();
  const [step, setStep] = useState(0);
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState(null);

  const [form, setForm] = useState({
    name: '',
    description: '',
    raceId: '',
    backgroundId: '',
    classId: '',
    subclassId: null,
    strength: 10,
    dexterity: 10,
    constitution: 10,
    intelligence: 10,
    wisdom: 10,
    charisma: 10,
    level: 1,
    armorClass: 10,
    maxHp: 10,
    currentHp: 10,
    speed: 30,
    hitDiceType: 8,
    alignmentId: '',
    sizeId: '',
    money: 0,
    language: 'common',
  });

  const [abilityMethod, setAbilityMethod] = useState('pointbuy'); // 'pointbuy' | '3d6' | '4d6drop'

  const { subclasses } = useSubclasses(form.classId ? Number(form.classId) : null);

  const updateForm = (field, value) => {
    setForm((prev) => ({ ...prev, [field]: value }));
  };

  // Point buy calculation
  const pointsSpent = ABILITY_NAMES.reduce((total, ab) => {
    const val = Math.min(15, Math.max(8, form[ab]));
    return total + (POINT_BUY_COSTS[val] || 0);
  }, 0);
  const pointsRemaining = POINT_BUY_TOTAL - pointsSpent;

  const handleRollAll = () => {
    const rollFn = abilityMethod === '3d6' ? roll3d6 : roll4d6DropLowest;
    const newValues = {};
    ABILITY_NAMES.forEach((ab) => {
      newValues[ab] = rollFn();
    });
    setForm((prev) => ({ ...prev, ...newValues }));
  };

  const handleSubmit = async () => {
    setSubmitting(true);
    setError(null);
    try {
      const payload = {
        name: form.name,
        classId: Number(form.classId),
        subclassId: form.subclassId ? Number(form.subclassId) : null,
        level: Number(form.level),
        strength: Number(form.strength),
        dexterity: Number(form.dexterity),
        constitution: Number(form.constitution),
        intelligence: Number(form.intelligence),
        wisdom: Number(form.wisdom),
        charisma: Number(form.charisma),
        backgroundId: Number(form.backgroundId),
        raceId: Number(form.raceId),
        armorClass: Number(form.armorClass),
        maxHp: Number(form.maxHp),
        currentHp: Number(form.currentHp),
        speed: Number(form.speed),
        hitDiceType: Number(form.hitDiceType),
        alignmentId: Number(form.alignmentId) || 1,
        sizeId: Number(form.sizeId) || 1,
        money: Number(form.money),
        language: form.language || 'common',
        description: form.description || null,
      };

      const res = await charactersApi.create(payload);
      navigate(`/characters/${res.data.id || res.data}`);
    } catch (err) {
      setError(err.response?.data?.message || err.response?.data || 'Failed to create character');
    } finally {
      setSubmitting(false);
    }
  };

  const canProceed = () => {
    switch (step) {
      case 0:
        return form.name.trim().length > 0;
      case 1:
        return form.raceId && form.backgroundId;
      case 2:
        return form.classId;
      case 3:
        return true;
      case 4:
        return form.maxHp > 0;
      default:
        return true;
    }
  };

  if (refLoading) {
    return <LoadingSpinner text="Loading reference data..." />;
  }

  const modifier = (val) => {
    const mod = Math.floor((val - 10) / 2);
    return mod >= 0 ? `+${mod}` : `${mod}`;
  };

  return (
    <div className="max-w-2xl mx-auto">
      <StepIndicator current={step} steps={STEPS} />

      <div className="card-parchment p-6 sm:p-8">
        <h2 className="text-lg font-cinzel font-bold text-gold-400 mb-1">{STEPS[step]}</h2>
        <div className="ornament-divider mb-6" style={{ marginTop: '0.5rem' }} />

        {error && (
          <div className="mb-4 p-3 rounded-md bg-blood-900/40 border border-blood-700/40 text-blood-300 text-sm">
            {typeof error === 'string' ? error : JSON.stringify(error)}
          </div>
        )}

        {/* Step 0: Basics */}
        {step === 0 && (
          <div className="space-y-5">
            <div>
              <label className="block text-sm font-cinzel text-obsidian-200 uppercase tracking-wider mb-2">
                Character Name *
              </label>
              <input
                type="text"
                value={form.name}
                onChange={(e) => updateForm('name', e.target.value)}
                className="input-field"
                placeholder="Name your hero..."
                autoFocus
              />
            </div>
            <div>
              <label className="block text-sm font-cinzel text-obsidian-200 uppercase tracking-wider mb-2">
                Description
              </label>
              <textarea
                value={form.description}
                onChange={(e) => updateForm('description', e.target.value)}
                className="input-field min-h-[120px] resize-y"
                placeholder="Describe your character's appearance, personality, backstory..."
              />
            </div>
          </div>
        )}

        {/* Step 1: Race & Background */}
        {step === 1 && (
          <div className="space-y-5">
            <div>
              <label className="block text-sm font-cinzel text-obsidian-200 uppercase tracking-wider mb-2">
                Race *
              </label>
              <select
                value={form.raceId}
                onChange={(e) => updateForm('raceId', e.target.value)}
                className="select-field"
              >
                <option value="">Select a race...</option>
                {races.map((r) => (
                  <option key={r.id} value={r.id}>
                    {r.name}
                  </option>
                ))}
              </select>
            </div>
            <div>
              <label className="block text-sm font-cinzel text-obsidian-200 uppercase tracking-wider mb-2">
                Background *
              </label>
              <select
                value={form.backgroundId}
                onChange={(e) => updateForm('backgroundId', e.target.value)}
                className="select-field"
              >
                <option value="">Select a background...</option>
                {backgrounds.map((b) => (
                  <option key={b.id} value={b.id}>
                    {b.name}
                  </option>
                ))}
              </select>
            </div>
            <div>
              <label className="block text-sm font-cinzel text-obsidian-200 uppercase tracking-wider mb-2">
                Alignment
              </label>
              <select
                value={form.alignmentId}
                onChange={(e) => updateForm('alignmentId', e.target.value)}
                className="select-field"
              >
                <option value="">Select alignment...</option>
                {alignments.map((a) => (
                  <option key={a.id} value={a.id}>
                    {a.alignment}
                  </option>
                ))}
              </select>
            </div>
            <div>
              <label className="block text-sm font-cinzel text-obsidian-200 uppercase tracking-wider mb-2">
                Size
              </label>
              <select
                value={form.sizeId}
                onChange={(e) => updateForm('sizeId', e.target.value)}
                className="select-field"
              >
                <option value="">Select size...</option>
                {sizes.map((s) => (
                  <option key={s.id} value={s.id}>
                    {s.name} ({s.space})
                  </option>
                ))}
              </select>
            </div>
          </div>
        )}

        {/* Step 2: Class */}
        {step === 2 && (
          <div className="space-y-5">
            <div>
              <label className="block text-sm font-cinzel text-obsidian-200 uppercase tracking-wider mb-2">
                Class *
              </label>
              <select
                value={form.classId}
                onChange={(e) => {
                  updateForm('classId', e.target.value);
                  updateForm('subclassId', null);
                }}
                className="select-field"
              >
                <option value="">Select a class...</option>
                {classes.map((c) => (
                  <option key={c.classId} value={c.classId}>
                    {c.className}
                  </option>
                ))}
              </select>
            </div>
            {subclasses.length > 0 && (
              <div>
                <label className="block text-sm font-cinzel text-obsidian-200 uppercase tracking-wider mb-2">
                  Subclass
                </label>
                <select
                  value={form.subclassId || ''}
                  onChange={(e) => updateForm('subclassId', e.target.value || null)}
                  className="select-field"
                >
                  <option value="">None (choose later)</option>
                  {subclasses.map((sc) => (
                    <option key={sc.id} value={sc.id}>
                      {sc.name}
                    </option>
                  ))}
                </select>
              </div>
            )}
            <div>
              <label className="block text-sm font-cinzel text-obsidian-200 uppercase tracking-wider mb-2">
                Level
              </label>
              <input
                type="number"
                min={1}
                max={20}
                value={form.level}
                onChange={(e) => updateForm('level', Number(e.target.value))}
                className="input-field w-24"
              />
            </div>
          </div>
        )}

        {/* Step 3: Abilities */}
        {step === 3 && (
          <div className="space-y-5">
            <div className="flex flex-wrap gap-2 mb-4">
              <button
                onClick={() => setAbilityMethod('pointbuy')}
                className={abilityMethod === 'pointbuy' ? 'btn-gold text-xs' : 'btn-ghost text-xs'}
              >
                Point Buy
              </button>
              <button
                onClick={() => setAbilityMethod('4d6drop')}
                className={abilityMethod === '4d6drop' ? 'btn-gold text-xs' : 'btn-ghost text-xs'}
              >
                4d6 Drop Lowest
              </button>
              <button
                onClick={() => setAbilityMethod('3d6')}
                className={abilityMethod === '3d6' ? 'btn-gold text-xs' : 'btn-ghost text-xs'}
              >
                3d6 Straight
              </button>
            </div>

            {abilityMethod !== 'pointbuy' && (
              <button onClick={handleRollAll} className="btn-ghost text-xs mb-4">
                🎲 Roll All Abilities
              </button>
            )}

            {abilityMethod === 'pointbuy' && (
              <div className="text-sm font-cinzel text-center mb-4">
                <span className={pointsRemaining < 0 ? 'text-blood-400' : 'text-gold-400'}>
                  Points remaining: {pointsRemaining}
                </span>
                <span className="text-obsidian-300"> / {POINT_BUY_TOTAL}</span>
              </div>
            )}

            <div className="grid grid-cols-2 sm:grid-cols-3 gap-4">
              {ABILITY_NAMES.map((ab) => (
                <div key={ab} className="stat-block">
                  <span className="stat-block-label">{ABILITY_LABELS[ab]}</span>
                  {abilityMethod === 'pointbuy' ? (
                    <div className="flex items-center gap-2 mt-1">
                      <button
                        onClick={() => updateForm(ab, Math.max(8, form[ab] - 1))}
                        className="w-6 h-6 rounded bg-obsidian-600 text-parchment-300 hover:bg-obsidian-500 text-sm flex items-center justify-center"
                      >
                        −
                      </button>
                      <span className="stat-block-value w-8 text-center">{form[ab]}</span>
                      <button
                        onClick={() => updateForm(ab, Math.min(15, form[ab] + 1))}
                        className="w-6 h-6 rounded bg-obsidian-600 text-parchment-300 hover:bg-obsidian-500 text-sm flex items-center justify-center"
                      >
                        +
                      </button>
                    </div>
                  ) : (
                    <input
                      type="number"
                      min={3}
                      max={18}
                      value={form[ab]}
                      onChange={(e) => updateForm(ab, Number(e.target.value))}
                      className="w-16 text-center bg-obsidian-700 border border-obsidian-500 rounded px-2 py-1 text-lg font-cinzel font-bold text-gold-400 mt-1"
                    />
                  )}
                  <span className="stat-block-modifier mt-1">{modifier(form[ab])}</span>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Step 4: Combat & Details */}
        {step === 4 && (
          <div className="space-y-5">
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-4">
              <div>
                <label className="block text-sm font-cinzel text-obsidian-200 uppercase tracking-wider mb-2">
                  Max HP
                </label>
                <input
                  type="number"
                  min={1}
                  value={form.maxHp}
                  onChange={(e) => {
                    const v = Number(e.target.value);
                    updateForm('maxHp', v);
                    updateForm('currentHp', v);
                  }}
                  className="input-field"
                />
              </div>
              <div>
                <label className="block text-sm font-cinzel text-obsidian-200 uppercase tracking-wider mb-2">
                  Armor Class
                </label>
                <input
                  type="number"
                  min={1}
                  value={form.armorClass}
                  onChange={(e) => updateForm('armorClass', Number(e.target.value))}
                  className="input-field"
                />
              </div>
              <div>
                <label className="block text-sm font-cinzel text-obsidian-200 uppercase tracking-wider mb-2">
                  Speed
                </label>
                <input
                  type="number"
                  min={0}
                  step={5}
                  value={form.speed}
                  onChange={(e) => updateForm('speed', Number(e.target.value))}
                  className="input-field"
                />
              </div>
              <div>
                <label className="block text-sm font-cinzel text-obsidian-200 uppercase tracking-wider mb-2">
                  Hit Dice Type
                </label>
                <select
                  value={form.hitDiceType}
                  onChange={(e) => updateForm('hitDiceType', Number(e.target.value))}
                  className="select-field"
                >
                  <option value={6}>d6</option>
                  <option value={8}>d8</option>
                  <option value={10}>d10</option>
                  <option value={12}>d12</option>
                </select>
              </div>
              <div>
                <label className="block text-sm font-cinzel text-obsidian-200 uppercase tracking-wider mb-2">
                  Starting Gold
                </label>
                <input
                  type="number"
                  min={0}
                  value={form.money}
                  onChange={(e) => updateForm('money', Number(e.target.value))}
                  className="input-field"
                />
              </div>
              <div>
                <label className="block text-sm font-cinzel text-obsidian-200 uppercase tracking-wider mb-2">
                  Languages
                </label>
                <input
                  type="text"
                  value={form.language}
                  onChange={(e) => updateForm('language', e.target.value)}
                  className="input-field"
                  placeholder="common, elvish..."
                />
              </div>
            </div>
          </div>
        )}

        {/* Navigation */}
        <div className="flex justify-between mt-8 pt-6 border-t border-obsidian-600/40">
          <button
            onClick={() => setStep((s) => Math.max(0, s - 1))}
            disabled={step === 0}
            className="btn-ghost"
          >
            ← Back
          </button>

          {step < STEPS.length - 1 ? (
            <button
              onClick={() => setStep((s) => s + 1)}
              disabled={!canProceed()}
              className="btn-gold"
            >
              Next →
            </button>
          ) : (
            <button onClick={handleSubmit} disabled={submitting || !canProceed()} className="btn-gold">
              {submitting ? 'Creating...' : 'Create Character'}
            </button>
          )}
        </div>
      </div>
    </div>
  );
}
