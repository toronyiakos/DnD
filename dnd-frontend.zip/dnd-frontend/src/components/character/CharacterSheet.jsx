import { useState } from 'react';
import SkillList from './SkillList';
import InventoryTab from './InventoryTab';
import SpellsTab from './SpellsTab';
import useAuthStore from '../../context/AuthContext';

const ABILITY_LABELS = {
  strength: 'STR',
  dexterity: 'DEX',
  constitution: 'CON',
  intelligence: 'INT',
  wisdom: 'WIS',
  charisma: 'CHA',
};

export default function CharacterSheet({ character, profBonus, onUpdate }) {
  const [activeTab, setActiveTab] = useState('skills');
  const [editingHp, setEditingHp] = useState(false);
  const [hpDelta, setHpDelta] = useState('');
  const role = useAuthStore((s) => s.role);
  const canEdit = role === 'game_master' || role === 'admin';

  if (!character) return null;

  const modifier = (val) => {
    const mod = Math.floor((val - 10) / 2);
    return mod >= 0 ? `+${mod}` : `${mod}`;
  };

  const hpPercent =
    character.maxHp > 0
      ? Math.max(0, Math.min(100, (character.currentHp / character.maxHp) * 100))
      : 0;

  let hpBarColor = 'bg-emerald-500';
  if (hpPercent < 25) hpBarColor = 'bg-blood-500';
  else if (hpPercent < 50) hpBarColor = 'bg-orange-500';
  else if (hpPercent < 75) hpBarColor = 'bg-yellow-500';

  const handleHpChange = async (amount) => {
    const newHp = Math.max(0, Math.min(character.maxHp, character.currentHp + amount));
    await onUpdate({ currentHp: newHp });
  };

  const handleHpDelta = async (positive) => {
    const val = parseInt(hpDelta, 10);
    if (isNaN(val) || val <= 0) return;
    await handleHpChange(positive ? val : -val);
    setHpDelta('');
    setEditingHp(false);
  };

  const tabs = [
    { id: 'skills', label: 'Skills' },
    { id: 'inventory', label: 'Inventory' },
    { id: 'spells', label: 'Spells' },
  ];

  return (
    <div className="page-enter">
      {/* Header */}
      <div className="card-parchment p-6 mb-6">
        <div className="flex flex-col sm:flex-row sm:items-start sm:justify-between gap-4">
          <div>
            <h1 className="text-2xl sm:text-3xl font-cinzel font-bold text-gold-400 text-shadow-glow">
              {character.name}
            </h1>
            <p className="text-sm text-parchment-300 mt-1">
              {character.raceName} {character.className}
              {character.subclassId ? ` — ${character.subclassName || ''}` : ''}
            </p>
            <div className="flex flex-wrap gap-x-4 gap-y-1 mt-2 text-xs font-cinzel text-obsidian-200 uppercase tracking-wider">
              {character.alignmentName && <span>{character.alignmentName}</span>}
              {character.sizeName && <span>{character.sizeName}</span>}
              {character.backgroundName && <span>{character.backgroundName}</span>}
            </div>
          </div>

          <div className="flex items-center gap-4 flex-shrink-0">
            <div className="text-center">
              <span className="text-3xl font-cinzel font-bold text-gold-400">{character.level}</span>
              <p className="text-[10px] font-cinzel uppercase tracking-[0.15em] text-obsidian-300">Level</p>
            </div>
            <div className="text-center">
              <span className="text-3xl font-cinzel font-bold text-parchment-100">{character.armorClass}</span>
              <p className="text-[10px] font-cinzel uppercase tracking-[0.15em] text-obsidian-300">AC</p>
            </div>
            <div className="text-center">
              <span className="text-3xl font-cinzel font-bold text-parchment-100">{character.speed}</span>
              <p className="text-[10px] font-cinzel uppercase tracking-[0.15em] text-obsidian-300">Speed</p>
            </div>
            <div className="text-center">
              <span className="text-3xl font-cinzel font-bold text-parchment-200">+{profBonus}</span>
              <p className="text-[10px] font-cinzel uppercase tracking-[0.15em] text-obsidian-300">Prof</p>
            </div>
          </div>
        </div>

        {/* HP Section */}
        <div className="mt-6 p-4 rounded-lg bg-obsidian-800/60 border border-obsidian-600/30">
          <div className="flex items-center justify-between mb-2">
            <span className="text-sm font-cinzel text-obsidian-200 uppercase tracking-wider">
              Hit Points
            </span>
            <span className="text-lg font-cinzel font-bold text-parchment-100">
              {character.currentHp} / {character.maxHp}
            </span>
          </div>
          <div className="h-3 rounded-full bg-obsidian-700 overflow-hidden mb-3">
            <div
              className={`h-full rounded-full ${hpBarColor} transition-all duration-500`}
              style={{ width: `${hpPercent}%` }}
            />
          </div>

          {/* HP Controls */}
          <div className="flex items-center gap-2 flex-wrap">
            <button
              onClick={() => handleHpChange(-1)}
              className="w-8 h-8 rounded bg-blood-700/60 text-blood-200 hover:bg-blood-600 transition-colors font-bold text-lg flex items-center justify-center"
              title="Damage 1"
            >
              −
            </button>
            <button
              onClick={() => handleHpChange(1)}
              className="w-8 h-8 rounded bg-emerald-700/60 text-emerald-200 hover:bg-emerald-600 transition-colors font-bold text-lg flex items-center justify-center"
              title="Heal 1"
            >
              +
            </button>

            <div className="flex items-center gap-1 ml-2">
              <input
                type="number"
                min={1}
                value={hpDelta}
                onChange={(e) => setHpDelta(e.target.value)}
                placeholder="Amount"
                className="w-20 px-2 py-1.5 rounded bg-obsidian-700 border border-obsidian-500 text-parchment-100 text-sm text-center focus:outline-none focus:border-gold-600"
              />
              <button
                onClick={() => handleHpDelta(false)}
                className="px-2 py-1.5 rounded bg-blood-700/60 text-blood-200 hover:bg-blood-600 transition-colors text-xs font-cinzel"
              >
                Damage
              </button>
              <button
                onClick={() => handleHpDelta(true)}
                className="px-2 py-1.5 rounded bg-emerald-700/60 text-emerald-200 hover:bg-emerald-600 transition-colors text-xs font-cinzel"
              >
                Heal
              </button>
            </div>
          </div>

          {/* Hit Dice & Money */}
          <div className="flex gap-4 mt-3 text-xs font-cinzel text-obsidian-200">
            <span>
              Hit Dice: {character.hitDiceNumber || character.level}d{character.hitDiceType}
            </span>
            <span>Gold: {character.money} gp</span>
            {character.language && <span>Languages: {character.language}</span>}
          </div>
        </div>

        {/* Description */}
        {character.description && (
          <div className="mt-4">
            <p className="text-sm text-parchment-300 italic leading-relaxed">
              {character.description}
            </p>
          </div>
        )}
      </div>

      {/* Ability Scores */}
      <div className="grid grid-cols-3 sm:grid-cols-6 gap-3 mb-6">
        {Object.entries(ABILITY_LABELS).map(([key, label]) => (
          <div key={key} className="stat-block">
            <span className="stat-block-label">{label}</span>
            <span className="stat-block-value">{character[key]}</span>
            <span className="stat-block-modifier">{modifier(character[key])}</span>
          </div>
        ))}
      </div>

      {/* Tabs */}
      <div className="border-b border-obsidian-600/40 mb-6">
        <div className="flex gap-1">
          {tabs.map((tab) => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`px-4 py-3 text-sm font-cinzel tracking-wider uppercase transition-all duration-200 ${
                activeTab === tab.id ? 'tab-active' : 'tab-inactive'
              }`}
            >
              {tab.label}
            </button>
          ))}
        </div>
      </div>

      {/* Tab Content */}
      <div className="card-parchment p-6">
        {activeTab === 'skills' && (
          <SkillList
            skills={character.skills}
            character={character}
            profBonus={profBonus}
          />
        )}
        {activeTab === 'inventory' && <InventoryTab characterId={character.id} />}
        {activeTab === 'spells' && (
          <SpellsTab classId={character.classId} characterLevel={character.level} />
        )}
      </div>
    </div>
  );
}
