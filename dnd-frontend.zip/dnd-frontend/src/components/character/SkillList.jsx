const SKILLS = [
  { key: 'acrobatics', label: 'Acrobatics', ability: 'Dex', profKey: 'acrobaticsDexProf', expKey: 'acrobaticsDexExp', stat: 'dexterity' },
  { key: 'animalHandling', label: 'Animal Handling', ability: 'Wis', profKey: 'animalHandlingWisProf', expKey: 'animalHandlingWisExp', stat: 'wisdom' },
  { key: 'arcana', label: 'Arcana', ability: 'Int', profKey: 'arcanaIntProf', expKey: 'arcanaIntExp', stat: 'intelligence' },
  { key: 'athletics', label: 'Athletics', ability: 'Str', profKey: 'athleticsStrProf', expKey: 'athleticsStrExp', stat: 'strength' },
  { key: 'deception', label: 'Deception', ability: 'Cha', profKey: 'deceptionChaProf', expKey: 'deceptionChaExp', stat: 'charisma' },
  { key: 'history', label: 'History', ability: 'Int', profKey: 'historyIntProf', expKey: 'historyIntExp', stat: 'intelligence' },
  { key: 'insight', label: 'Insight', ability: 'Wis', profKey: 'insightWisProf', expKey: 'insightWisExp', stat: 'wisdom' },
  { key: 'intimidation', label: 'Intimidation', ability: 'Cha', profKey: 'intimidationChaProf', expKey: 'intimidationChaExp', stat: 'charisma' },
  { key: 'investigation', label: 'Investigation', ability: 'Int', profKey: 'investigationIntProf', expKey: 'investigationIntExp', stat: 'intelligence' },
  { key: 'medicine', label: 'Medicine', ability: 'Wis', profKey: 'medicineWisProf', expKey: 'medicineWisExp', stat: 'wisdom' },
  { key: 'nature', label: 'Nature', ability: 'Wis', profKey: 'natureWisProf', expKey: 'natureWisExp', stat: 'wisdom' },
  { key: 'perception', label: 'Perception', ability: 'Wis', profKey: 'perceptionWisProf', expKey: 'perceptionWisExp', stat: 'wisdom' },
  { key: 'performance', label: 'Performance', ability: 'Cha', profKey: 'performanceChaProf', expKey: 'performanceChaExp', stat: 'charisma' },
  { key: 'persuasion', label: 'Persuasion', ability: 'Cha', profKey: 'persuasionChaProf', expKey: 'persuasionChaExp', stat: 'charisma' },
  { key: 'religion', label: 'Religion', ability: 'Int', profKey: 'religionIntProf', expKey: 'religionIntExp', stat: 'intelligence' },
  { key: 'sleightOfHand', label: 'Sleight of Hand', ability: 'Dex', profKey: 'sleightOfHandDexProf', expKey: 'sleightOfHandDexExp', stat: 'dexterity' },
  { key: 'stealth', label: 'Stealth', ability: 'Dex', profKey: 'stealthDexProf', expKey: 'stealthDexExp', stat: 'dexterity' },
  { key: 'survival', label: 'Survival', ability: 'Wis', profKey: 'survivalWisProf', expKey: 'survivalWisExp', stat: 'wisdom' },
];

export default function SkillList({ skills, character, profBonus = 2 }) {
  if (!skills || !character) return null;

  const getModifier = (statValue) => Math.floor((statValue - 10) / 2);

  const getSkillBonus = (skill) => {
    const statMod = getModifier(character[skill.stat]);
    const isProf = skills[skill.profKey];
    const isExp = skills[skill.expKey];
    const isJack = skills.jackOfAllTrades;

    let bonus = statMod;
    if (isExp) {
      bonus += profBonus * 2;
    } else if (isProf) {
      bonus += profBonus;
    } else if (isJack) {
      bonus += Math.floor(profBonus / 2);
    }
    return bonus;
  };

  const formatBonus = (val) => (val >= 0 ? `+${val}` : `${val}`);

  return (
    <div className="space-y-1">
      <h3 className="text-sm font-cinzel font-bold text-gold-400 uppercase tracking-wider mb-3">
        Skills
      </h3>
      {SKILLS.map((skill) => {
        const isProf = skills[skill.profKey];
        const isExp = skills[skill.expKey];
        const bonus = getSkillBonus(skill);

        return (
          <div
            key={skill.key}
            className="flex items-center gap-2 py-1 px-2 rounded hover:bg-obsidian-700/50 transition-colors"
          >
            {/* Proficiency indicators */}
            <div className="flex gap-1 flex-shrink-0">
              <span
                className={`w-2.5 h-2.5 rounded-full border ${
                  isProf
                    ? 'bg-gold-500 border-gold-400'
                    : 'bg-transparent border-obsidian-400'
                }`}
                title={isProf ? 'Proficient' : 'Not proficient'}
              />
              <span
                className={`w-2.5 h-2.5 rounded-full border ${
                  isExp
                    ? 'bg-gold-300 border-gold-200'
                    : 'bg-transparent border-obsidian-400'
                }`}
                title={isExp ? 'Expertise' : 'No expertise'}
              />
            </div>

            {/* Bonus */}
            <span
              className={`text-sm font-cinzel font-bold w-8 text-right ${
                isProf || isExp ? 'text-gold-400' : 'text-obsidian-200'
              }`}
            >
              {formatBonus(bonus)}
            </span>

            {/* Name */}
            <span className="text-sm text-parchment-200 flex-1">{skill.label}</span>

            {/* Ability tag */}
            <span className="text-[10px] font-cinzel text-obsidian-300 uppercase">
              {skill.ability}
            </span>
          </div>
        );
      })}
    </div>
  );
}
