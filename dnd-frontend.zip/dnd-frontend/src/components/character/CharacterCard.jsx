import { Link } from 'react-router-dom';

const classIcons = {
  Fighter: '⚔️',
  Wizard: '🔮',
  Rogue: '🗡️',
  Cleric: '✝️',
  Ranger: '🏹',
  Paladin: '🛡️',
  Barbarian: '🪓',
  Bard: '🎵',
  Druid: '🌿',
  Monk: '👊',
  Sorcerer: '✨',
  Warlock: '🔥',
};

export default function CharacterCard({ character }) {
  // CharacterSummaryDto fields: id, name, className, raceName, level, currentHp, maxHp
  const { id, name, className, raceName, level, maxHp, currentHp } = character;

  const hpPercent = maxHp > 0 ? Math.max(0, Math.min(100, (currentHp / maxHp) * 100)) : 0;
  const icon = classIcons[className] || '🎭';

  let hpColor = 'bg-emerald-500';
  if (hpPercent < 25) hpColor = 'bg-blood-500';
  else if (hpPercent < 50) hpColor = 'bg-orange-500';
  else if (hpPercent < 75) hpColor = 'bg-yellow-500';

  return (
    <Link to={`/characters/${id}`} className="block group">
      <div className="card-parchment p-5 transition-all duration-300 hover:border-gold-500/50 hover:shadow-glow-gold group-hover:-translate-y-0.5">
        <div className="flex items-start justify-between mb-3">
          <div className="flex-1 min-w-0">
            <h3 className="text-lg font-cinzel font-bold text-parchment-100 truncate group-hover:text-gold-300 transition-colors">
              {name}
            </h3>
            <p className="text-sm text-obsidian-200 mt-0.5">
              {raceName} {className}
            </p>
          </div>
          <span className="text-2xl ml-3 flex-shrink-0">{icon}</span>
        </div>

        <div className="flex items-center gap-4 mb-3">
          <div className="flex items-center gap-1.5">
            <span className="text-[10px] font-cinzel uppercase tracking-wider text-obsidian-300">LVL</span>
            <span className="text-lg font-cinzel font-bold text-gold-400">{level}</span>
          </div>
        </div>

        {/* HP bar */}
        <div>
          <div className="flex justify-between items-baseline mb-1">
            <span className="text-[10px] font-cinzel uppercase tracking-wider text-obsidian-300">
              Hit Points
            </span>
            <span className="text-sm font-cinzel text-parchment-200">
              {currentHp} / {maxHp}
            </span>
          </div>
          <div className="h-2 rounded-full bg-obsidian-800 overflow-hidden">
            <div
              className={`h-full rounded-full ${hpColor} transition-all duration-500`}
              style={{ width: `${hpPercent}%` }}
            />
          </div>
        </div>
      </div>
    </Link>
  );
}
