import { useState } from 'react';
import { useClassSpells, useClassSpellSlots } from '../../hooks/useReferenceData';
import LoadingSpinner from '../ui/LoadingSpinner';
import SpellCard from '../spell/SpellCard';

export default function SpellsTab({ classId, characterLevel }) {
  const [selectedLevel, setSelectedLevel] = useState(undefined);
  const { spells, loading: spellsLoading } = useClassSpells(classId, selectedLevel);
  const { spellSlots, loading: slotsLoading } = useClassSpellSlots(classId);
  const [expandedSpell, setExpandedSpell] = useState(null);

  // Find spell slots for current character level
  const currentSlots = spellSlots.find(
    (s) => s.level === characterLevel || s.classLevel === characterLevel
  );

  const spellLevels = [
    { value: undefined, label: 'All' },
    { value: 0, label: 'Cantrips' },
    ...Array.from({ length: 9 }, (_, i) => ({ value: i + 1, label: `Level ${i + 1}` })),
  ];

  // Group spells by level
  const grouped = {};
  (spells || []).forEach((spell) => {
    const lvl = spell.spellLevel ?? 0;
    if (!grouped[lvl]) grouped[lvl] = [];
    grouped[lvl].push(spell);
  });

  const sortedLevels = Object.keys(grouped)
    .map(Number)
    .sort((a, b) => a - b);

  return (
    <div>
      <div className="flex items-center justify-between mb-4 flex-wrap gap-2">
        <h3 className="text-sm font-cinzel font-bold text-gold-400 uppercase tracking-wider">
          Class Spells
        </h3>
      </div>

      {/* Spell Slot Display */}
      {currentSlots && (
        <div className="mb-4 p-3 rounded-lg bg-obsidian-800/40 border border-obsidian-600/20">
          <p className="text-[10px] font-cinzel text-obsidian-300 uppercase tracking-wider mb-2">
            Spell Slots (Level {characterLevel})
          </p>
          {currentSlots.cantrip != null && currentSlots.cantrip > 0 && (
            <div className="text-xs text-obsidian-200 mb-2">
              Cantrips known: <span className="text-gold-400 font-bold">{currentSlots.cantrip}</span>
            </div>
          )}
          <div className="flex flex-wrap gap-3">
            {/* Dnd5SpellSlot fields: _1st, _2nd, _3rd, _4th, _5th, _6th, _7th, _8th, _9th */}
            {[
              { lvl: 1, key: '_1st' },
              { lvl: 2, key: '_2nd' },
              { lvl: 3, key: '_3rd' },
              { lvl: 4, key: '_4th' },
              { lvl: 5, key: '_5th' },
              { lvl: 6, key: '_6th' },
              { lvl: 7, key: '_7th' },
              { lvl: 8, key: '_8th' },
              { lvl: 9, key: '_9th' },
            ].map(({ lvl, key }) => {
              const slotCount = currentSlots[key] ?? 0;
              if (slotCount <= 0) return null;
              return (
                <div key={lvl} className="text-center">
                  <span className="text-sm font-cinzel font-bold text-gold-400">{slotCount}</span>
                  <p className="text-[9px] font-cinzel text-obsidian-300 uppercase">Lv{lvl}</p>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* Level filter */}
      <div className="flex flex-wrap gap-1 mb-4">
        {spellLevels.map((lvl) => (
          <button
            key={lvl.label}
            onClick={() => setSelectedLevel(lvl.value)}
            className={`px-2 py-1 rounded text-xs font-cinzel transition-all ${
              selectedLevel === lvl.value
                ? 'bg-gold-600/30 text-gold-300 border border-gold-500/40'
                : 'bg-obsidian-700 text-obsidian-300 border border-obsidian-600 hover:text-parchment-200'
            }`}
          >
            {lvl.label}
          </button>
        ))}
      </div>

      {spellsLoading ? (
        <LoadingSpinner size="sm" text="Loading spells..." />
      ) : spells.length === 0 ? (
        <p className="text-obsidian-300 text-sm italic text-center py-8">
          No spells available for this class.
        </p>
      ) : (
        <div className="space-y-4">
          {sortedLevels.map((level) => (
            <div key={level}>
              <h4 className="text-xs font-cinzel text-obsidian-200 uppercase tracking-wider mb-2 border-b border-obsidian-600/30 pb-1">
                {level === 0 ? 'Cantrips' : `Level ${level}`}
              </h4>
              <div className="space-y-2">
                {grouped[level].map((spell) => (
                  <div key={spell.spellId || spell.id}>
                    <button
                      onClick={() =>
                        setExpandedSpell(
                          expandedSpell === (spell.spellId || spell.id)
                            ? null
                            : spell.spellId || spell.id
                        )
                      }
                      className={`w-full text-left p-3 rounded-lg transition-all ${
                        expandedSpell === (spell.spellId || spell.id)
                          ? 'bg-obsidian-700 border border-gold-600/30'
                          : 'bg-obsidian-800/40 border border-obsidian-600/20 hover:bg-obsidian-700/60'
                      }`}
                    >
                      <div className="flex items-center justify-between">
                        <span className="text-sm font-semibold text-parchment-100">
                          {spell.spellName || spell.name}
                        </span>
                        <span className="text-[10px] font-cinzel text-obsidian-300 uppercase">
                          {spell.spellType || spell.school}
                        </span>
                      </div>
                    </button>

                    {expandedSpell === (spell.spellId || spell.id) && (
                      <div className="mt-1 p-4 rounded-lg bg-obsidian-800/60 border border-obsidian-600/20 animate-[fadeSlideIn_0.15s_ease-out]">
                        <SpellCard spell={spell} compact />
                      </div>
                    )}
                  </div>
                ))}
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
