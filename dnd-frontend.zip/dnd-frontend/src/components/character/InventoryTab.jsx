import { useState } from 'react';
import { useCharacterInventory } from '../../hooks/useCharacters';
import { itemsApi } from '../../api/items';
import useAuthStore from '../../context/AuthContext';
import LoadingSpinner from '../ui/LoadingSpinner';
import Modal from '../ui/Modal';

export default function InventoryTab({ characterId }) {
  const { inventory, loading, error, addItem, removeItem } = useCharacterInventory(characterId);
  const [showAddModal, setShowAddModal] = useState(false);
  const [allItems, setAllItems] = useState([]);
  const [itemsLoading, setItemsLoading] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const role = useAuthStore((s) => s.role);
  const canEdit = role === 'game_master' || role === 'admin';

  const handleOpenAdd = async () => {
    setShowAddModal(true);
    setItemsLoading(true);
    try {
      const res = await itemsApi.getAll();
      setAllItems(res.data);
    } catch (err) {
      console.error('Failed to load items', err);
    } finally {
      setItemsLoading(false);
    }
  };

  const filteredItems = allItems.filter((item) =>
    item.name?.toLowerCase().includes(searchQuery.toLowerCase())
  );

  if (loading) return <LoadingSpinner size="sm" text="Loading inventory..." />;
  if (error) return <p className="text-blood-400 text-sm">{error}</p>;

  return (
    <div>
      <div className="flex items-center justify-between mb-4">
        <h3 className="text-sm font-cinzel font-bold text-gold-400 uppercase tracking-wider">
          Inventory
        </h3>
        <button onClick={handleOpenAdd} className="btn-ghost text-xs py-1 px-3">
          + Add Item
        </button>
      </div>

      {inventory.length === 0 ? (
        <p className="text-obsidian-300 text-sm italic text-center py-8">
          No items in inventory. Add some equipment!
        </p>
      ) : (
        <div className="space-y-2">
          {inventory.map((item, idx) => (
            <div
              key={item.id || idx}
              className="flex items-center justify-between p-3 rounded-lg bg-obsidian-800/60 border border-obsidian-600/30 hover:border-obsidian-400/40 transition-colors"
            >
              <div className="flex-1 min-w-0">
                <p className="text-sm font-semibold text-parchment-100 truncate">
                  {item.name}
                  {item.attuned && (
                    <span className="ml-1.5 text-[9px] font-cinzel text-purple-400 uppercase">(Attuned)</span>
                  )}
                </p>
                <div className="flex gap-3 text-xs text-obsidian-300">
                  {item.typeName && <span>{item.typeName}</span>}
                  {item.weight > 0 && <span>{item.weight} lb</span>}
                  {item.price != null && item.price > 0 && <span>{item.price} gp</span>}
                </div>
              </div>
              {item.rarityName && (
                <span className="text-[10px] font-cinzel uppercase tracking-wider text-gold-500 mx-2">
                  {item.rarityName}
                </span>
              )}
              <button
                onClick={() => removeItem(item.id)}
                className="text-blood-400 hover:text-blood-300 transition-colors ml-2 flex-shrink-0"
                title="Remove item"
              >
                <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                </svg>
              </button>
            </div>
          ))}
        </div>
      )}

      {/* Add Item Modal */}
      <Modal
        isOpen={showAddModal}
        onClose={() => setShowAddModal(false)}
        title="Add Item to Inventory"
        maxWidth="max-w-md"
      >
        <input
          type="text"
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          className="input-field mb-4"
          placeholder="Search items..."
          autoFocus
        />

        {itemsLoading ? (
          <LoadingSpinner size="sm" />
        ) : (
          <div className="max-h-64 overflow-y-auto space-y-1">
            {filteredItems.map((item) => (
              <button
                key={item.id}
                onClick={async () => {
                  await addItem(item.id);
                  setShowAddModal(false);
                  setSearchQuery('');
                }}
                className="w-full text-left p-3 rounded hover:bg-obsidian-600 transition-colors flex justify-between items-center"
              >
                <span className="text-sm text-parchment-100">{item.name}</span>
                {item.rarityName && (
                  <span className="text-[10px] font-cinzel text-gold-500 uppercase">
                    {item.rarityName}
                  </span>
                )}
              </button>
            ))}
            {filteredItems.length === 0 && (
              <p className="text-obsidian-300 text-sm text-center py-4">No items found</p>
            )}
          </div>
        )}
      </Modal>
    </div>
  );
}
