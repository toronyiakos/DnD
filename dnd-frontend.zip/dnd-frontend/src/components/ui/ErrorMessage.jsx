export default function ErrorMessage({ message, onRetry }) {
  return (
    <div className="flex flex-col items-center justify-center gap-4 py-12">
      <div className="w-16 h-16 rounded-full bg-blood-900/50 border border-blood-600/40 flex items-center justify-center">
        <svg className="w-8 h-8 text-blood-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
          <path
            strokeLinecap="round"
            strokeLinejoin="round"
            strokeWidth={2}
            d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-2.5L13.732 4c-.77-.833-1.964-.833-2.732 0L4.082 16.5c-.77.833.192 2.5 1.732 2.5z"
          />
        </svg>
      </div>
      <p className="text-blood-300 font-crimson text-lg text-center max-w-md">{message}</p>
      {onRetry && (
        <button onClick={onRetry} className="btn-ghost text-xs">
          Try Again
        </button>
      )}
    </div>
  );
}
