export default function LoadingSpinner({ size = 'md', text = 'Loading...' }) {
  const sizeClasses = {
    sm: 'w-5 h-5 border-2',
    md: 'w-8 h-8 border-[3px]',
    lg: 'w-12 h-12 border-4',
  };

  return (
    <div className="flex flex-col items-center justify-center gap-3 py-12">
      <div
        className={`${sizeClasses[size]} rounded-full border-obsidian-500 border-t-gold-500 animate-spin`}
      />
      {text && (
        <p className="text-sm font-cinzel text-obsidian-200 tracking-wider uppercase animate-pulse">
          {text}
        </p>
      )}
    </div>
  );
}
