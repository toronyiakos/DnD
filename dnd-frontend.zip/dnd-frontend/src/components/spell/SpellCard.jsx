const SPELL_LEVEL_COLORS = {
  0: 'border-l-emerald-500',
  1: 'border-l-blue-400',
  2: 'border-l-indigo-400',
  3: 'border-l-purple-400',
  4: 'border-l-pink-400',
  5: 'border-l-red-400',
  6: 'border-l-orange-400',
  7: 'border-l-yellow-400',
  8: 'border-l-amber-300',
  9: 'border-l-gold-400',
};

export default function SpellCard({ spell, compact = false, onEdit, onDelete, canManage = false }) {
  if (!spell) return null;

  const level = spell.spellLevel ?? 0;
  const borderClass = SPELL_LEVEL_COLORS[level] || 'border-l-obsidian-400';
  const name = spell.spellName || spell.name || 'Unknown Spell';

  if (compact) {
    return (
      <div className="space-y-2 text-sm">
        <div className="grid grid-cols-2 gap-x-4 gap-y-1 text-xs">
          <div>
            <span className="text-obsidian-300">Casting Time: </span>
            <span className="text-parchment-200">{spell.castingTime || '—'}</span>
          </div>
          <div>
            <span className="text-obsidian-300">Range: </span>
            <span className="text-parchment-200">{spell.spellRange || spell.range || '—'}</span>
          </div>
          <div>
            <span className="text-obsidian-300">Components: </span>
            <span className="text-parchment-200">{spell.components || '—'}</span>
          </div>
          <div>
            <span className="text-obsidian-300">Duration: </span>
            <span className="text-parchment-200">{spell.duration || '—'}</span>
          </div>
        </div>
        {spell.description && (
          <p className="text-parchment-300 text-sm leading-relaxed">{spell.description}</p>
        )}
        {spell.higherLevels && (
          <p className="text-xs text-obsidian-200 italic">
            <span className="text-gold-500 font-semibold">At Higher Levels: </span>
            {spell.higherLevels}
          </p>
        )}
      </div>
    );
  }

  return (
    <div
      className={`card-parchment p-5 border-l-4 ${borderClass} transition-all duration-200 hover:border-opacity-100`}
    >
      <div className="flex items-start justify-between mb-2">
        <div>
          <h3 className="text-lg font-cinzel font-bold text-parchment-100">{name}</h3>
          <p className="text-xs text-obsidian-200 mt-0.5">
            {level === 0 ? 'Cantrip' : `Level ${level}`}
            {spell.spellType && ` • ${spell.spellType}`}
          </p>
        </div>
        {canManage && (
          <div className="flex gap-1 flex-shrink-0">
            {onEdit && (
              <button
                onClick={() => onEdit(spell)}
                className="p-1.5 rounded text-obsidian-300 hover:text-gold-400 hover:bg-obsidian-600 transition-colors"
                title="Edit"
              >
                <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z" />
                </svg>
              </button>
            )}
            {onDelete && (
              <button
                onClick={() => onDelete(spell)}
                className="p-1.5 rounded text-obsidian-300 hover:text-blood-400 hover:bg-obsidian-600 transition-colors"
                title="Delete"
              >
                <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" />
                </svg>
              </button>
            )}
          </div>
        )}
      </div>

      <div className="grid grid-cols-2 gap-x-4 gap-y-1 text-xs mb-3">
        <div>
          <span className="text-obsidian-300">Casting Time: </span>
          <span className="text-parchment-200">{spell.castingTime || '—'}</span>
        </div>
        <div>
          <span className="text-obsidian-300">Range: </span>
          <span className="text-parchment-200">{spell.spellRange || spell.range || '—'}</span>
        </div>
        <div>
          <span className="text-obsidian-300">Components: </span>
          <span className="text-parchment-200">{spell.components || '—'}</span>
        </div>
        <div>
          <span className="text-obsidian-300">Duration: </span>
          <span className="text-parchment-200">{spell.duration || '—'}</span>
        </div>
      </div>

      {spell.description && (
        <p className="text-sm text-parchment-300 leading-relaxed">{spell.description}</p>
      )}

      {spell.higherLevels && (
        <p className="text-xs text-obsidian-200 italic mt-2">
          <span className="text-gold-500 font-semibold">At Higher Levels: </span>
          {spell.higherLevels}
        </p>
      )}
    </div>
  );
}
