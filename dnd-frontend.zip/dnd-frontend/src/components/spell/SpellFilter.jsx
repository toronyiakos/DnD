import { useState, useEffect } from 'react';
import { classesApi } from '../../api/classes';

export default function SpellFilter({ filters, onChange }) {
  const [classes, setClasses] = useState([]);

  useEffect(() => {
    classesApi
      .getAll()
      .then((res) => setClasses(res.data))
      .catch(() => setClasses([]));
  }, []);

  const spellTypes = [
    'Abjuration',
    'Conjuration',
    'Divination',
    'Enchantment',
    'Evocation',
    'Illusion',
    'Necromancy',
    'Transmutation',
  ];

  return (
    <div className="card-parchment p-4 mb-6">
      <div className="flex flex-wrap gap-4 items-end">
        {/* Level filter */}
        <div className="flex-1 min-w-[120px]">
          <label className="block text-[10px] font-cinzel text-obsidian-300 uppercase tracking-wider mb-1.5">
            Spell Level
          </label>
          <select
            value={filters.level ?? ''}
            onChange={(e) => onChange({ ...filters, level: e.target.value })}
            className="select-field py-2 text-sm"
          >
            <option value="">All Levels</option>
            <option value="0">Cantrips</option>
            {[1, 2, 3, 4, 5, 6, 7, 8, 9].map((l) => (
              <option key={l} value={l}>
                Level {l}
              </option>
            ))}
          </select>
        </div>

        {/* Type/School filter */}
        <div className="flex-1 min-w-[140px]">
          <label className="block text-[10px] font-cinzel text-obsidian-300 uppercase tracking-wider mb-1.5">
            School
          </label>
          <select
            value={filters.type || ''}
            onChange={(e) => onChange({ ...filters, type: e.target.value })}
            className="select-field py-2 text-sm"
          >
            <option value="">All Schools</option>
            {spellTypes.map((t) => (
              <option key={t} value={t}>
                {t}
              </option>
            ))}
          </select>
        </div>

        {/* Class filter */}
        <div className="flex-1 min-w-[120px]">
          <label className="block text-[10px] font-cinzel text-obsidian-300 uppercase tracking-wider mb-1.5">
            Class
          </label>
          <select
            value={filters.classId || ''}
            onChange={(e) => onChange({ ...filters, classId: e.target.value })}
            className="select-field py-2 text-sm"
          >
            <option value="">All Classes</option>
            {classes.map((c) => (
              <option key={c.classId} value={c.classId}>
                {c.className}
              </option>
            ))}
          </select>
        </div>

        {/* Clear */}
        <button
          onClick={() => onChange({ level: '', type: '', classId: '' })}
          className="btn-ghost text-xs py-2"
        >
          Clear
        </button>
      </div>
    </div>
  );
}
