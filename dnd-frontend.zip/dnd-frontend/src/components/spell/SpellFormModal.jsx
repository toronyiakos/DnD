import { useState, useEffect } from 'react';
import Modal from '../ui/Modal';

const EMPTY_SPELL = {
  spellName: '',
  spellLevel: 0,
  spellType: '',
  castingTime: '',
  spellRange: '',
  components: '',
  duration: '',
  description: '',
  higherLevels: '',
};

export default function SpellFormModal({ isOpen, onClose, onSubmit, spell = null }) {
  const [form, setForm] = useState(EMPTY_SPELL);
  const [submitting, setSubmitting] = useState(false);
  const isEditing = !!spell;

  useEffect(() => {
    if (spell) {
      setForm({
        spellName: spell.spellName || '',
        spellLevel: spell.spellLevel ?? 0,
        spellType: spell.spellType || '',
        castingTime: spell.castingTime || '',
        spellRange: spell.spellRange || '',
        components: spell.components || '',
        duration: spell.duration || '',
        description: spell.description || '',
        higherLevels: spell.higherLevels || '',
      });
    } else {
      setForm(EMPTY_SPELL);
    }
  }, [spell, isOpen]);

  const handleSubmit = async () => {
    setSubmitting(true);
    try {
      await onSubmit(form);
      onClose();
    } catch (err) {
      console.error(err);
    } finally {
      setSubmitting(false);
    }
  };

  const update = (field, value) => setForm((prev) => ({ ...prev, [field]: value }));

  const spellTypes = [
    'Abjuration', 'Conjuration', 'Divination', 'Enchantment',
    'Evocation', 'Illusion', 'Necromancy', 'Transmutation',
  ];

  return (
    <Modal
      isOpen={isOpen}
      onClose={onClose}
      title={isEditing ? 'Edit Spell' : 'Create Spell'}
      maxWidth="max-w-lg"
    >
      <div className="space-y-4">
        <div>
          <label className="block text-sm font-cinzel text-obsidian-200 uppercase tracking-wider mb-1.5">
            Spell Name *
          </label>
          <input
            type="text"
            value={form.spellName}
            onChange={(e) => update('spellName', e.target.value)}
            className="input-field"
            placeholder="Name of the spell..."
          />
        </div>

        <div className="grid grid-cols-2 gap-4">
          <div>
            <label className="block text-sm font-cinzel text-obsidian-200 uppercase tracking-wider mb-1.5">
              Level
            </label>
            <select
              value={form.spellLevel}
              onChange={(e) => update('spellLevel', Number(e.target.value))}
              className="select-field"
            >
              <option value={0}>Cantrip</option>
              {[1, 2, 3, 4, 5, 6, 7, 8, 9].map((l) => (
                <option key={l} value={l}>Level {l}</option>
              ))}
            </select>
          </div>
          <div>
            <label className="block text-sm font-cinzel text-obsidian-200 uppercase tracking-wider mb-1.5">
              School
            </label>
            <select
              value={form.spellType}
              onChange={(e) => update('spellType', e.target.value)}
              className="select-field"
            >
              <option value="">Select school...</option>
              {spellTypes.map((t) => (
                <option key={t} value={t}>{t}</option>
              ))}
            </select>
          </div>
        </div>

        <div className="grid grid-cols-2 gap-4">
          <div>
            <label className="block text-sm font-cinzel text-obsidian-200 uppercase tracking-wider mb-1.5">
              Casting Time
            </label>
            <input
              type="text"
              value={form.castingTime}
              onChange={(e) => update('castingTime', e.target.value)}
              className="input-field"
              placeholder="1 action"
            />
          </div>
          <div>
            <label className="block text-sm font-cinzel text-obsidian-200 uppercase tracking-wider mb-1.5">
              Range
            </label>
            <input
              type="text"
              value={form.spellRange}
              onChange={(e) => update('spellRange', e.target.value)}
              className="input-field"
              placeholder="120 feet"
            />
          </div>
        </div>

        <div className="grid grid-cols-2 gap-4">
          <div>
            <label className="block text-sm font-cinzel text-obsidian-200 uppercase tracking-wider mb-1.5">
              Components
            </label>
            <input
              type="text"
              value={form.components}
              onChange={(e) => update('components', e.target.value)}
              className="input-field"
              placeholder="V, S, M"
            />
          </div>
          <div>
            <label className="block text-sm font-cinzel text-obsidian-200 uppercase tracking-wider mb-1.5">
              Duration
            </label>
            <input
              type="text"
              value={form.duration}
              onChange={(e) => update('duration', e.target.value)}
              className="input-field"
              placeholder="Instantaneous"
            />
          </div>
        </div>

        <div>
          <label className="block text-sm font-cinzel text-obsidian-200 uppercase tracking-wider mb-1.5">
            Description
          </label>
          <textarea
            value={form.description}
            onChange={(e) => update('description', e.target.value)}
            className="input-field min-h-[100px] resize-y"
            placeholder="Describe the spell's effect..."
          />
        </div>

        <div>
          <label className="block text-sm font-cinzel text-obsidian-200 uppercase tracking-wider mb-1.5">
            At Higher Levels
          </label>
          <textarea
            value={form.higherLevels}
            onChange={(e) => update('higherLevels', e.target.value)}
            className="input-field min-h-[60px] resize-y"
            placeholder="When cast using a higher level slot..."
          />
        </div>

        <div className="flex justify-end gap-3 pt-2">
          <button onClick={onClose} className="btn-ghost">
            Cancel
          </button>
          <button
            onClick={handleSubmit}
            disabled={submitting || !form.spellName.trim()}
            className="btn-gold"
          >
            {submitting ? 'Saving...' : isEditing ? 'Update Spell' : 'Create Spell'}
          </button>
        </div>
      </div>
    </Modal>
  );
}
