import { useState, useEffect } from 'react';
import { referenceApi } from '../api/reference';
import { racesApi } from '../api/races';
import { classesApi } from '../api/classes';
import { backgroundsApi } from '../api/backgrounds';

export function useReferenceData() {
  const [data, setData] = useState({
    alignments: [],
    sizes: [],
    races: [],
    classes: [],
    backgrounds: [],
    monsterTypes: [],
    itemTypes: [],
    itemRarities: [],
  });
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    const fetchAll = async () => {
      setLoading(true);
      try {
        const [alignments, sizes, races, classes, backgrounds, monsterTypes, itemTypes, itemRarities] =
          await Promise.all([
            referenceApi.getAlignments(),
            referenceApi.getSizes(),
            racesApi.getAll(),
            classesApi.getAll(),
            backgroundsApi.getAll(),
            referenceApi.getMonsterTypes(),
            referenceApi.getItemTypes(),
            referenceApi.getItemRarities(),
          ]);

        setData({
          alignments: alignments.data,
          sizes: sizes.data,
          races: races.data,
          classes: classes.data,
          backgrounds: backgrounds.data,
          monsterTypes: monsterTypes.data,
          itemTypes: itemTypes.data,
          itemRarities: itemRarities.data,
        });
      } catch (err) {
        setError(err.response?.data?.message || 'Failed to load reference data');
      } finally {
        setLoading(false);
      }
    };

    fetchAll();
  }, []);

  return { ...data, loading, error };
}

export function useSubclasses(classId) {
  const [subclasses, setSubclasses] = useState([]);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (!classId) {
      setSubclasses([]);
      return;
    }
    setLoading(true);
    classesApi
      .getSubclasses(classId)
      .then((res) => setSubclasses(res.data))
      .catch(() => setSubclasses([]))
      .finally(() => setLoading(false));
  }, [classId]);

  return { subclasses, loading };
}

export function useClassSpells(classId, level) {
  const [spells, setSpells] = useState([]);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (!classId) {
      setSpells([]);
      return;
    }
    setLoading(true);
    classesApi
      .getSpells(classId, level)
      .then((res) => setSpells(res.data))
      .catch(() => setSpells([]))
      .finally(() => setLoading(false));
  }, [classId, level]);

  return { spells, loading };
}

export function useClassSpellSlots(classId) {
  const [spellSlots, setSpellSlots] = useState([]);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (!classId) {
      setSpellSlots([]);
      return;
    }
    setLoading(true);
    classesApi
      .getSpellSlots(classId)
      .then((res) => setSpellSlots(res.data))
      .catch(() => setSpellSlots([]))
      .finally(() => setLoading(false));
  }, [classId]);

  return { spellSlots, loading };
}

export function useProfByLevel() {
  const [profTable, setProfTable] = useState([]);

  useEffect(() => {
    referenceApi
      .getProfByLevel()
      .then((res) => setProfTable(res.data))
      .catch(() => setProfTable([]));
  }, []);

  return profTable;
}

export function useSubraces(raceId) {
  const [subraces, setSubraces] = useState([]);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (!raceId) {
      setSubraces([]);
      return;
    }
    setLoading(true);
    racesApi
      .getSubraces(raceId)
      .then((res) => setSubraces(res.data))
      .catch(() => setSubraces([]))
      .finally(() => setLoading(false));
  }, [raceId]);

  return { subraces, loading };
}

export function useRacials(raceId) {
  const [racials, setRacials] = useState([]);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (!raceId) {
      setRacials([]);
      return;
    }
    setLoading(true);
    racesApi
      .getRacials(raceId)
      .then((res) => setRacials(res.data))
      .catch(() => setRacials([]))
      .finally(() => setLoading(false));
  }, [raceId]);

  return { racials, loading };
}
