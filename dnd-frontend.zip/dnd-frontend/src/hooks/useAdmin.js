import { useState, useEffect, useCallback } from 'react';
import { adminApi } from '../api/admin';

export function useAdmin() {
  const [users, setUsers] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  const fetchUsers = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const res = await adminApi.getUsers();
      setUsers(res.data);
    } catch (err) {
      setError(err.response?.data?.message || 'Failed to load users');
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    fetchUsers();
  }, [fetchUsers]);

  const updateRole = async (userId, roleId) => {
    try {
      await adminApi.updateRole(userId, roleId);
      await fetchUsers();
      return true;
    } catch (err) {
      setError(err.response?.data?.message || 'Failed to update role');
      return false;
    }
  };

  const deleteUser = async (userId) => {
    try {
      await adminApi.deleteUser(userId);
      await fetchUsers();
      return true;
    } catch (err) {
      setError(err.response?.data?.message || 'Failed to delete user');
      return false;
    }
  };

  return { users, loading, error, refetch: fetchUsers, updateRole, deleteUser };
}
