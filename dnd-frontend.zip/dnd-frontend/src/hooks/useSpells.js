import { useState, useEffect, useCallback } from 'react';
import { spellsApi } from '../api/spells';

export function useSpells(filters = {}) {
  const [spells, setSpells] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  const fetchSpells = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const res = await spellsApi.getAll(filters);
      setSpells(res.data);
    } catch (err) {
      setError(err.response?.data?.message || 'Failed to load spells');
    } finally {
      setLoading(false);
    }
  }, [filters.level, filters.type, filters.classId]);

  useEffect(() => {
    fetchSpells();
  }, [fetchSpells]);

  return { spells, loading, error, refetch: fetchSpells };
}

export function useSpell(id) {
  const [spell, setSpell] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    if (!id) return;
    setLoading(true);
    spellsApi
      .getById(id)
      .then((res) => setSpell(res.data))
      .catch((err) => setError(err.response?.data?.message || 'Failed to load spell'))
      .finally(() => setLoading(false));
  }, [id]);

  return { spell, loading, error };
}
