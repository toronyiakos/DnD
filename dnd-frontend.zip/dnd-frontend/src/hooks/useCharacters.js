import { useState, useEffect, useCallback } from 'react';
import { charactersApi } from '../api/characters';

export function useCharacters() {
  const [characters, setCharacters] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  const fetchCharacters = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const res = await charactersApi.getAll();
      setCharacters(res.data);
    } catch (err) {
      setError(err.response?.data?.message || 'Failed to load characters');
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    fetchCharacters();
  }, [fetchCharacters]);

  return { characters, loading, error, refetch: fetchCharacters };
}

export function useCharacter(id) {
  const [character, setCharacter] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  const fetchCharacter = useCallback(async () => {
    if (!id) return;
    setLoading(true);
    setError(null);
    try {
      const res = await charactersApi.getById(id);
      setCharacter(res.data);
    } catch (err) {
      setError(err.response?.data?.message || 'Failed to load character');
    } finally {
      setLoading(false);
    }
  }, [id]);

  useEffect(() => {
    fetchCharacter();
  }, [fetchCharacter]);

  const updateCharacter = async (data) => {
    try {
      await charactersApi.update(id, data);
      await fetchCharacter();
      return true;
    } catch (err) {
      setError(err.response?.data?.message || 'Failed to update character');
      return false;
    }
  };

  return { character, loading, error, refetch: fetchCharacter, updateCharacter };
}

export function useCharacterInventory(characterId) {
  const [inventory, setInventory] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  const fetchInventory = useCallback(async () => {
    if (!characterId) return;
    setLoading(true);
    try {
      const res = await charactersApi.getInventory(characterId);
      setInventory(res.data);
    } catch (err) {
      setError(err.response?.data?.message || 'Failed to load inventory');
    } finally {
      setLoading(false);
    }
  }, [characterId]);

  useEffect(() => {
    fetchInventory();
  }, [fetchInventory]);

  const addItem = async (itemId) => {
    try {
      await charactersApi.addItem(characterId, itemId);
      await fetchInventory();
      return true;
    } catch (err) {
      setError(err.response?.data?.message || 'Failed to add item');
      return false;
    }
  };

  const removeItem = async (itemId) => {
    try {
      await charactersApi.removeItem(characterId, itemId);
      await fetchInventory();
      return true;
    } catch (err) {
      setError(err.response?.data?.message || 'Failed to remove item');
      return false;
    }
  };

  return { inventory, loading, error, refetch: fetchInventory, addItem, removeItem };
}
