import BattleMap from '../components/map/BattleMap';

export default function MapPage() {
  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 py-8 page-enter">
      <div className="mb-6">
        <h1 className="text-2xl sm:text-3xl font-cinzel font-bold text-gold-400 text-shadow-glow">
          Battlemap
        </h1>
        <p className="text-sm text-obsidian-200 mt-1">
          Tactical grid for encounters and exploration
        </p>
      </div>

      <BattleMap />

      {/* Info */}
      <div className="mt-6 card-parchment p-4">
        <h3 className="text-sm font-cinzel font-bold text-gold-400 mb-2">Controls</h3>
        <div className="grid sm:grid-cols-3 gap-3 text-xs text-obsidian-200">
          <div className="flex items-center gap-2">
            <span className="w-6 h-6 rounded-full bg-gold-600 flex items-center justify-center text-[8px] text-white font-bold">
              PC
            </span>
            <span>Player characters (gold)</span>
          </div>
          <div className="flex items-center gap-2">
            <span className="w-6 h-6 rounded-full bg-blood-600 flex items-center justify-center text-[8px] text-white font-bold">
              MO
            </span>
            <span>Monsters (red)</span>
          </div>
          <div className="flex items-center gap-2">
            <span className="w-6 h-6 rounded-full bg-emerald-600 flex items-center justify-center text-[8px] text-white font-bold">
              NP
            </span>
            <span>NPCs (green)</span>
          </div>
        </div>
        <p className="text-xs text-obsidian-300 mt-3 italic">
          Note: Battlemap data is currently stored locally. Backend map controller integration will persist token positions across sessions.
        </p>
      </div>
    </div>
  );
}
