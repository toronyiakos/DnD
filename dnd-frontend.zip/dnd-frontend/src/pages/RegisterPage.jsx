import { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import useAuthStore from '../context/AuthContext';

export default function RegisterPage() {
  const [name, setName] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [localError, setLocalError] = useState('');
  const { register, loading, error, clearError } = useAuthStore();
  const navigate = useNavigate();

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLocalError('');

    if (password !== confirmPassword) {
      setLocalError('Passwords do not match');
      return;
    }

    if (password.length < 4) {
      setLocalError('Password must be at least 4 characters');
      return;
    }

    const success = await register(name, password);
    if (success) {
      navigate('/characters');
    }
  };

  const displayError = localError || error;

  return (
    <div className="min-h-screen flex items-center justify-center px-4 relative overflow-hidden">
      {/* Background decoration */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div className="absolute top-1/3 right-1/4 w-96 h-96 rounded-full bg-gold-600/5 blur-3xl" />
        <div className="absolute bottom-1/3 left-1/4 w-80 h-80 rounded-full bg-blood-600/5 blur-3xl" />
      </div>

      <div className="relative w-full max-w-md">
        {/* Header */}
        <div className="text-center mb-8">
          <h1 className="text-4xl font-cinzel font-bold text-gold-400 text-shadow-glow tracking-wider">
            Realm Codex
          </h1>
          <p className="mt-2 text-sm font-cinzel text-obsidian-200 tracking-[0.25em] uppercase">
            Join the Adventure
          </p>
          <div className="ornament-divider mt-4" />
        </div>

        {/* Register form */}
        <div className="card-parchment p-8">
          <h2 className="text-xl font-cinzel font-semibold text-parchment-100 mb-6 text-center">
            Create Account
          </h2>

          {displayError && (
            <div className="mb-4 p-3 rounded-md bg-blood-900/40 border border-blood-700/40 text-blood-300 text-sm">
              {displayError}
            </div>
          )}

          <form onSubmit={handleSubmit} className="space-y-5">
            <div>
              <label className="block text-sm font-cinzel text-obsidian-200 uppercase tracking-wider mb-2">
                Username
              </label>
              <input
                type="text"
                value={name}
                onChange={(e) => {
                  clearError();
                  setLocalError('');
                  setName(e.target.value);
                }}
                className="input-field"
                placeholder="Choose a name..."
                required
                autoFocus
              />
            </div>

            <div>
              <label className="block text-sm font-cinzel text-obsidian-200 uppercase tracking-wider mb-2">
                Password
              </label>
              <input
                type="password"
                value={password}
                onChange={(e) => {
                  clearError();
                  setLocalError('');
                  setPassword(e.target.value);
                }}
                className="input-field"
                placeholder="Choose a password..."
                required
              />
            </div>

            <div>
              <label className="block text-sm font-cinzel text-obsidian-200 uppercase tracking-wider mb-2">
                Confirm Password
              </label>
              <input
                type="password"
                value={confirmPassword}
                onChange={(e) => {
                  setLocalError('');
                  setConfirmPassword(e.target.value);
                }}
                className="input-field"
                placeholder="Confirm your password..."
                required
              />
            </div>

            <button type="submit" disabled={loading} className="btn-gold w-full py-3">
              {loading ? (
                <span className="flex items-center justify-center gap-2">
                  <span className="w-4 h-4 border-2 border-obsidian-900/30 border-t-obsidian-900 rounded-full animate-spin" />
                  Creating Account...
                </span>
              ) : (
                'Forge Your Destiny'
              )}
            </button>
          </form>

          <div className="ornament-divider" />

          <p className="text-center text-sm text-obsidian-200">
            Already have an account?{' '}
            <Link to="/login" className="text-gold-400 hover:text-gold-300 font-semibold transition-colors">
              Sign In
            </Link>
          </p>
        </div>
      </div>
    </div>
  );
}
