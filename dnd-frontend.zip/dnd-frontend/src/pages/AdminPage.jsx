import { useState } from 'react';
import { useAdmin } from '../hooks/useAdmin';
import LoadingSpinner from '../components/ui/LoadingSpinner';
import ErrorMessage from '../components/ui/ErrorMessage';
import ConfirmDialog from '../components/ui/ConfirmDialog';

const ROLES = [
  { id: 0, name: 'user', label: 'User' },
  { id: 1, name: 'game_master', label: 'Game Master' },
  { id: 2, name: 'admin', label: 'Admin' },
];

export default function AdminPage() {
  const { users, loading, error, refetch, updateRole, deleteUser } = useAdmin();
  const [deleteTarget, setDeleteTarget] = useState(null);
  const [updatingId, setUpdatingId] = useState(null);

  const handleRoleChange = async (userId, roleId) => {
    setUpdatingId(userId);
    await updateRole(userId, Number(roleId));
    setUpdatingId(null);
  };

  const handleDelete = async () => {
    if (!deleteTarget) return;
    await deleteUser(deleteTarget.id);
    setDeleteTarget(null);
  };

  const getRoleBadgeColor = (role) => {
    switch (role) {
      case 'admin':
        return 'bg-blood-900/40 text-blood-300 border-blood-700/40';
      case 'game_master':
        return 'bg-gold-900/40 text-gold-300 border-gold-700/40';
      default:
        return 'bg-obsidian-700 text-obsidian-200 border-obsidian-500';
    }
  };

  return (
    <div className="max-w-5xl mx-auto px-4 sm:px-6 py-8 page-enter">
      <div className="mb-8">
        <h1 className="text-2xl sm:text-3xl font-cinzel font-bold text-gold-400 text-shadow-glow">
          Admin Panel
        </h1>
        <p className="text-sm text-obsidian-200 mt-1">
          Manage users and their roles
        </p>
      </div>

      {loading ? (
        <LoadingSpinner text="Loading users..." />
      ) : error ? (
        <ErrorMessage message={error} onRetry={refetch} />
      ) : (
        <div className="card-parchment overflow-hidden">
          {/* Table header */}
          <div className="hidden sm:grid sm:grid-cols-12 gap-4 px-6 py-3 bg-obsidian-800/60 border-b border-obsidian-600/30">
            <span className="col-span-1 text-[10px] font-cinzel text-obsidian-300 uppercase tracking-wider">
              ID
            </span>
            <span className="col-span-4 text-[10px] font-cinzel text-obsidian-300 uppercase tracking-wider">
              Username
            </span>
            <span className="col-span-3 text-[10px] font-cinzel text-obsidian-300 uppercase tracking-wider">
              Current Role
            </span>
            <span className="col-span-3 text-[10px] font-cinzel text-obsidian-300 uppercase tracking-wider">
              Change Role
            </span>
            <span className="col-span-1 text-[10px] font-cinzel text-obsidian-300 uppercase tracking-wider text-right">
              Actions
            </span>
          </div>

          {/* User rows */}
          <div className="divide-y divide-obsidian-600/20">
            {users.map((user) => (
              <div
                key={user.id}
                className="grid grid-cols-1 sm:grid-cols-12 gap-2 sm:gap-4 px-6 py-4 hover:bg-obsidian-700/30 transition-colors items-center"
              >
                {/* ID */}
                <div className="col-span-1 text-sm text-obsidian-300 font-mono">
                  <span className="sm:hidden text-[10px] font-cinzel text-obsidian-400 uppercase mr-2">ID:</span>
                  #{user.id}
                </div>

                {/* Username */}
                <div className="col-span-4">
                  <span className="sm:hidden text-[10px] font-cinzel text-obsidian-400 uppercase mr-2">User:</span>
                  <span className="text-sm font-semibold text-parchment-100">{user.name}</span>
                </div>

                {/* Current Role Badge */}
                <div className="col-span-3">
                  <span className="sm:hidden text-[10px] font-cinzel text-obsidian-400 uppercase mr-2">Role:</span>
                  <span
                    className={`inline-block px-2 py-0.5 rounded text-[10px] font-cinzel uppercase tracking-wider border ${getRoleBadgeColor(
                      user.roleName
                    )}`}
                  >
                    {user.roleName || 'user'}
                  </span>
                </div>

                {/* Role Selector */}
                <div className="col-span-3">
                  <select
                    value={user.roleId ?? 0}
                    onChange={(e) => handleRoleChange(user.id, e.target.value)}
                    disabled={updatingId === user.id}
                    className="select-field py-1.5 text-xs"
                  >
                    {ROLES.map((r) => (
                      <option key={r.id} value={r.id}>
                        {r.label}
                      </option>
                    ))}
                  </select>
                </div>

                {/* Delete */}
                <div className="col-span-1 text-right">
                  <button
                    onClick={() => setDeleteTarget(user)}
                    className="p-1.5 rounded text-obsidian-300 hover:text-blood-400 hover:bg-blood-900/30 transition-colors"
                    title="Delete user"
                  >
                    <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" />
                    </svg>
                  </button>
                </div>
              </div>
            ))}
          </div>

          {users.length === 0 && (
            <div className="text-center py-12">
              <p className="text-obsidian-300 text-sm">No users found</p>
            </div>
          )}
        </div>
      )}

      {/* Confirm Delete */}
      <ConfirmDialog
        isOpen={deleteTarget !== null}
        onClose={() => setDeleteTarget(null)}
        onConfirm={handleDelete}
        title="Delete User"
        message={`Are you sure you want to permanently delete user "${deleteTarget?.name || ''}"? This will also delete all their characters and data.`}
      />
    </div>
  );
}
