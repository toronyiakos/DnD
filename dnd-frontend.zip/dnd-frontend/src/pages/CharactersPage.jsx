import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useCharacters } from '../hooks/useCharacters';
import { charactersApi } from '../api/characters';
import CharacterCard from '../components/character/CharacterCard';
import CharacterWizard from '../components/character/CharacterWizard';
import LoadingSpinner from '../components/ui/LoadingSpinner';
import ErrorMessage from '../components/ui/ErrorMessage';
import ConfirmDialog from '../components/ui/ConfirmDialog';
import useAuthStore from '../context/AuthContext';

export default function CharactersPage() {
  const { characters, loading, error, refetch } = useCharacters();
  const [showWizard, setShowWizard] = useState(false);
  const [deleteTarget, setDeleteTarget] = useState(null);
  const role = useAuthStore((s) => s.role);
  const canManage = role === 'game_master' || role === 'admin';
  const navigate = useNavigate();

  const handleDelete = async () => {
    if (!deleteTarget) return;
    try {
      await charactersApi.delete(deleteTarget);
      refetch();
    } catch (err) {
      console.error('Delete failed', err);
    }
  };

  if (showWizard) {
    return (
      <div className="max-w-7xl mx-auto px-4 sm:px-6 py-8 page-enter">
        <div className="flex items-center justify-between mb-6">
          <h1 className="text-2xl font-cinzel font-bold text-gold-400 text-shadow-glow">
            Create Character
          </h1>
          <button onClick={() => setShowWizard(false)} className="btn-ghost text-xs">
            ← Back to List
          </button>
        </div>
        <CharacterWizard />
      </div>
    );
  }

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 py-8 page-enter">
      {/* Header */}
      <div className="flex items-center justify-between mb-8">
        <div>
          <h1 className="text-2xl sm:text-3xl font-cinzel font-bold text-gold-400 text-shadow-glow">
            Characters
          </h1>
          <p className="text-sm text-obsidian-200 mt-1">
            {characters.length} character{characters.length !== 1 ? 's' : ''} in your party
          </p>
        </div>
        <button onClick={() => setShowWizard(true)} className="btn-gold">
          + New Character
        </button>
      </div>

      {/* Content */}
      {loading ? (
        <LoadingSpinner text="Summoning characters..." />
      ) : error ? (
        <ErrorMessage message={error} onRetry={refetch} />
      ) : characters.length === 0 ? (
        <div className="text-center py-16">
          <div className="text-6xl mb-4 opacity-30">⚔️</div>
          <h2 className="text-xl font-cinzel text-obsidian-200 mb-2">No Characters Yet</h2>
          <p className="text-sm text-obsidian-300 mb-6">
            Create your first character to begin your adventure.
          </p>
          <button onClick={() => setShowWizard(true)} className="btn-gold">
            Create Your First Character
          </button>
        </div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {characters.map((char) => (
            <div key={char.id} className="relative group">
              <CharacterCard character={char} />
              {/* Delete button overlay - all users can delete own characters, backend checks ownership */}
              <button
                onClick={(e) => {
                  e.preventDefault();
                  e.stopPropagation();
                  setDeleteTarget(char.id);
                }}
                className="absolute top-3 right-3 opacity-0 group-hover:opacity-100 transition-opacity p-1.5 rounded bg-obsidian-800/80 text-blood-400 hover:text-blood-300 hover:bg-blood-900/60"
                title="Delete character"
              >
                  <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" />
                  </svg>
                </button>
            </div>
          ))}
        </div>
      )}

      {/* Confirm Delete */}
      <ConfirmDialog
        isOpen={deleteTarget !== null}
        onClose={() => setDeleteTarget(null)}
        onConfirm={handleDelete}
        title="Delete Character"
        message="Are you sure you want to permanently delete this character? This action cannot be undone."
      />
    </div>
  );
}
