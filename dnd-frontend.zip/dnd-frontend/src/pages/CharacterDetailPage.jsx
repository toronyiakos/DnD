import { useParams, useNavigate } from 'react-router-dom';
import { useCharacter } from '../hooks/useCharacters';
import { useProfByLevel } from '../hooks/useReferenceData';
import CharacterSheet from '../components/character/CharacterSheet';
import LoadingSpinner from '../components/ui/LoadingSpinner';
import ErrorMessage from '../components/ui/ErrorMessage';

export default function CharacterDetailPage() {
  const { id } = useParams();
  const navigate = useNavigate();
  const { character, loading, error, refetch, updateCharacter } = useCharacter(id);
  const profTable = useProfByLevel();

  // Get proficiency bonus for current level
  // Backend Dnd5Profbylevel: { level: string, bonus: string } - both are strings
  let profBonus = 2;
  if (character && profTable.length > 0) {
    const charLevel = String(character.level);
    const entry = profTable.find((p) => String(p.level) === charLevel);
    if (entry) {
      // bonus might be something like "+2" or "2"
      const parsed = parseInt(String(entry.bonus).replace('+', ''), 10);
      profBonus = isNaN(parsed) ? 2 : parsed;
    } else {
      // Fallback calculation: proficiency = floor((level-1)/4) + 2
      profBonus = Math.floor((character.level - 1) / 4) + 2;
    }
  }

  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 py-8">
      {/* Back button */}
      <button
        onClick={() => navigate('/characters')}
        className="flex items-center gap-1 text-sm font-cinzel text-obsidian-300 hover:text-gold-400 transition-colors mb-6"
      >
        <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" />
        </svg>
        Back to Characters
      </button>

      {loading ? (
        <LoadingSpinner text="Loading character sheet..." />
      ) : error ? (
        <ErrorMessage message={error} onRetry={refetch} />
      ) : character ? (
        <CharacterSheet
          character={character}
          profBonus={profBonus}
          onUpdate={updateCharacter}
        />
      ) : (
        <ErrorMessage message="Character not found" />
      )}
    </div>
  );
}
