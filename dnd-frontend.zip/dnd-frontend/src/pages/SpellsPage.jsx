import { useState, useCallback } from 'react';
import { useSpells } from '../hooks/useSpells';
import { spellsApi } from '../api/spells';
import SpellCard from '../components/spell/SpellCard';
import SpellFilter from '../components/spell/SpellFilter';
import SpellFormModal from '../components/spell/SpellFormModal';
import LoadingSpinner from '../components/ui/LoadingSpinner';
import ErrorMessage from '../components/ui/ErrorMessage';
import ConfirmDialog from '../components/ui/ConfirmDialog';
import useAuthStore from '../context/AuthContext';

export default function SpellsPage() {
  const [filters, setFilters] = useState({ level: '', type: '', classId: '' });
  const { spells, loading, error, refetch } = useSpells(filters);
  const role = useAuthStore((s) => s.role);
  const canManage = role === 'game_master' || role === 'admin';
  const isAdmin = role === 'admin';

  const [showForm, setShowForm] = useState(false);
  const [editingSpell, setEditingSpell] = useState(null);
  const [deleteTarget, setDeleteTarget] = useState(null);

  const handleCreate = async (data) => {
    await spellsApi.create(data);
    refetch();
  };

  const handleUpdate = async (data) => {
    if (!editingSpell) return;
    await spellsApi.update(editingSpell.spellId || editingSpell.id, data);
    setEditingSpell(null);
    refetch();
  };

  const handleDelete = async () => {
    if (!deleteTarget) return;
    try {
      await spellsApi.delete(deleteTarget.spellId || deleteTarget.id);
      refetch();
    } catch (err) {
      console.error('Delete failed', err);
    }
  };

  const handleEdit = (spell) => {
    setEditingSpell(spell);
  };

  // Group spells by level
  const grouped = {};
  (spells || []).forEach((spell) => {
    const lvl = spell.spellLevel ?? 0;
    if (!grouped[lvl]) grouped[lvl] = [];
    grouped[lvl].push(spell);
  });

  const sortedLevels = Object.keys(grouped)
    .map(Number)
    .sort((a, b) => a - b);

  return (
    <div className="max-w-5xl mx-auto px-4 sm:px-6 py-8 page-enter">
      {/* Header */}
      <div className="flex items-center justify-between mb-6">
        <div>
          <h1 className="text-2xl sm:text-3xl font-cinzel font-bold text-gold-400 text-shadow-glow">
            Spell Compendium
          </h1>
          <p className="text-sm text-obsidian-200 mt-1">
            Browse and search all available spells
          </p>
        </div>
        {canManage && (
          <button onClick={() => setShowForm(true)} className="btn-gold">
            + New Spell
          </button>
        )}
      </div>

      {/* Filters */}
      <SpellFilter filters={filters} onChange={setFilters} />

      {/* Content */}
      {loading ? (
        <LoadingSpinner text="Channeling arcane knowledge..." />
      ) : error ? (
        <ErrorMessage message={error} onRetry={refetch} />
      ) : spells.length === 0 ? (
        <div className="text-center py-16">
          <div className="text-6xl mb-4 opacity-30">🔮</div>
          <h2 className="text-xl font-cinzel text-obsidian-200 mb-2">No Spells Found</h2>
          <p className="text-sm text-obsidian-300">
            Try adjusting your filters or search criteria.
          </p>
        </div>
      ) : (
        <div className="space-y-8">
          {sortedLevels.map((level) => (
            <div key={level}>
              <h2 className="text-sm font-cinzel font-bold text-gold-500 uppercase tracking-[0.2em] mb-4 flex items-center gap-3">
                <span>{level === 0 ? 'Cantrips' : `Level ${level} Spells`}</span>
                <span className="flex-1 h-px bg-gradient-to-r from-gold-600/30 to-transparent" />
                <span className="text-obsidian-300 text-[10px] font-normal">
                  {grouped[level].length} spell{grouped[level].length !== 1 ? 's' : ''}
                </span>
              </h2>
              <div className="grid gap-4 sm:grid-cols-2">
                {grouped[level].map((spell) => (
                  <SpellCard
                    key={spell.spellId || spell.id}
                    spell={spell}
                    canManage={canManage}
                    onEdit={canManage ? handleEdit : undefined}
                    onDelete={isAdmin ? (s) => setDeleteTarget(s) : undefined}
                  />
                ))}
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Create Spell Modal */}
      <SpellFormModal
        isOpen={showForm}
        onClose={() => setShowForm(false)}
        onSubmit={handleCreate}
      />

      {/* Edit Spell Modal */}
      <SpellFormModal
        isOpen={editingSpell !== null}
        onClose={() => setEditingSpell(null)}
        onSubmit={handleUpdate}
        spell={editingSpell}
      />

      {/* Confirm Delete */}
      <ConfirmDialog
        isOpen={deleteTarget !== null}
        onClose={() => setDeleteTarget(null)}
        onConfirm={handleDelete}
        title="Delete Spell"
        message={`Are you sure you want to delete "${deleteTarget?.spellName || ''}"? This action cannot be undone.`}
      />
    </div>
  );
}
