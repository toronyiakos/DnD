import { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import useAuthStore from '../context/AuthContext';

export default function LoginPage() {
  const [name, setName] = useState('');
  const [password, setPassword] = useState('');
  const { login, loading, error, clearError } = useAuthStore();
  const navigate = useNavigate();

  const handleSubmit = async (e) => {
    e.preventDefault();
    const success = await login(name, password);
    if (success) {
      navigate('/characters');
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center px-4 relative overflow-hidden">
      {/* Background decoration */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div className="absolute top-1/4 left-1/4 w-96 h-96 rounded-full bg-gold-600/5 blur-3xl" />
        <div className="absolute bottom-1/4 right-1/4 w-80 h-80 rounded-full bg-blood-600/5 blur-3xl" />
      </div>

      <div className="relative w-full max-w-md">
        {/* Header */}
        <div className="text-center mb-8">
          <h1 className="text-4xl font-cinzel font-bold text-gold-400 text-shadow-glow tracking-wider">
            Realm Codex
          </h1>
          <p className="mt-2 text-sm font-cinzel text-obsidian-200 tracking-[0.25em] uppercase">
            D&D 5th Edition Platform
          </p>
          <div className="ornament-divider mt-4" />
        </div>

        {/* Login form */}
        <div className="card-parchment p-8">
          <h2 className="text-xl font-cinzel font-semibold text-parchment-100 mb-6 text-center">
            Sign In
          </h2>

          {error && (
            <div className="mb-4 p-3 rounded-md bg-blood-900/40 border border-blood-700/40 text-blood-300 text-sm">
              {error}
            </div>
          )}

          <form onSubmit={handleSubmit} className="space-y-5">
            <div>
              <label className="block text-sm font-cinzel text-obsidian-200 uppercase tracking-wider mb-2">
                Username
              </label>
              <input
                type="text"
                value={name}
                onChange={(e) => {
                  clearError();
                  setName(e.target.value);
                }}
                className="input-field"
                placeholder="Enter your name..."
                required
                autoFocus
              />
            </div>

            <div>
              <label className="block text-sm font-cinzel text-obsidian-200 uppercase tracking-wider mb-2">
                Password
              </label>
              <input
                type="password"
                value={password}
                onChange={(e) => {
                  clearError();
                  setPassword(e.target.value);
                }}
                className="input-field"
                placeholder="Enter your password..."
                required
              />
            </div>

            <button type="submit" disabled={loading} className="btn-gold w-full py-3">
              {loading ? (
                <span className="flex items-center justify-center gap-2">
                  <span className="w-4 h-4 border-2 border-obsidian-900/30 border-t-obsidian-900 rounded-full animate-spin" />
                  Authenticating...
                </span>
              ) : (
                'Enter the Realm'
              )}
            </button>
          </form>

          <div className="ornament-divider" />

          <p className="text-center text-sm text-obsidian-200">
            No account yet?{' '}
            <Link to="/register" className="text-gold-400 hover:text-gold-300 font-semibold transition-colors">
              Register
            </Link>
          </p>
        </div>
      </div>
    </div>
  );
}
