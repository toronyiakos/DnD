import { createBrowserRouter, RouterProvider, Navigate } from 'react-router-dom';
import MainLayout from './components/layout/MainLayout';
import ProtectedRoute from './components/layout/ProtectedRoute';
import LoginPage from './pages/LoginPage';
import RegisterPage from './pages/RegisterPage';
import CharactersPage from './pages/CharactersPage';
import CharacterDetailPage from './pages/CharacterDetailPage';
import SpellsPage from './pages/SpellsPage';
import MapPage from './pages/MapPage';
import AdminPage from './pages/AdminPage';

const router = createBrowserRouter([
  {
    path: '/login',
    element: <LoginPage />,
  },
  {
    path: '/register',
    element: <RegisterPage />,
  },
  {
    path: '/',
    element: <ProtectedRoute />,
    children: [
      {
        element: <MainLayout />,
        children: [
          {
            index: true,
            element: <Navigate to="/characters" replace />,
          },
          {
            path: 'characters',
            element: <CharactersPage />,
          },
          {
            path: 'characters/:id',
            element: <CharacterDetailPage />,
          },
          {
            path: 'spells',
            element: <SpellsPage />,
          },
          {
            path: 'map',
            element: <MapPage />,
          },
        ],
      },
    ],
  },
  {
    path: '/admin',
    element: <ProtectedRoute requiredRole="admin" />,
    children: [
      {
        element: <MainLayout />,
        children: [
          {
            index: true,
            element: <AdminPage />,
          },
        ],
      },
    ],
  },
  {
    path: '*',
    element: <Navigate to="/characters" replace />,
  },
]);

export default function App() {
  return <RouterProvider router={router} />;
}
