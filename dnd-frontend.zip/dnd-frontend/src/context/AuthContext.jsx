import { create } from 'zustand';
import { authApi } from '../api/auth';

const useAuthStore = create((set, get) => ({
  token: localStorage.getItem('dnd_token') || null,
  user: localStorage.getItem('dnd_user') || null,
  role: localStorage.getItem('dnd_role') || null,
  expiresAt: localStorage.getItem('dnd_expires_at') || null,
  loading: false,
  error: null,

  get isAuthenticated() {
    const state = get();
    if (!state.token) return false;
    if (state.expiresAt && new Date(state.expiresAt) < new Date()) {
      get().logout();
      return false;
    }
    return true;
  },

  isGameMaster() {
    const role = get().role;
    return role === 'game_master' || role === 'admin';
  },

  isAdmin() {
    return get().role === 'admin';
  },

  login: async (name, password) => {
    set({ loading: true, error: null });
    try {
      const res = await authApi.login(name, password);
      const { token, username, role, expiresAt } = res.data;
      localStorage.setItem('dnd_token', token);
      localStorage.setItem('dnd_user', username);
      localStorage.setItem('dnd_role', role);
      localStorage.setItem('dnd_expires_at', expiresAt);
      set({ token, user: username, role, expiresAt, loading: false, error: null });
      return true;
    } catch (err) {
      const msg = err.response?.data?.message || err.response?.data || 'Login failed';
      set({ loading: false, error: typeof msg === 'string' ? msg : 'Login failed' });
      return false;
    }
  },

  register: async (name, password) => {
    set({ loading: true, error: null });
    try {
      const res = await authApi.register(name, password);
      const { token, username, role, expiresAt } = res.data;
      localStorage.setItem('dnd_token', token);
      localStorage.setItem('dnd_user', username);
      localStorage.setItem('dnd_role', role);
      localStorage.setItem('dnd_expires_at', expiresAt);
      set({ token, user: username, role, expiresAt, loading: false, error: null });
      return true;
    } catch (err) {
      const msg = err.response?.data?.message || err.response?.data || 'Registration failed';
      set({ loading: false, error: typeof msg === 'string' ? msg : 'Registration failed' });
      return false;
    }
  },

  logout: () => {
    localStorage.removeItem('dnd_token');
    localStorage.removeItem('dnd_user');
    localStorage.removeItem('dnd_role');
    localStorage.removeItem('dnd_expires_at');
    set({ token: null, user: null, role: null, expiresAt: null, error: null });
  },

  clearError: () => set({ error: null }),
}));

export default useAuthStore;
