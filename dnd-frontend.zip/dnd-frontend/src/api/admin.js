import api from './axiosInstance';

export const adminApi = {
  getUsers() {
    return api.get('/api/admin/user');
  },

  getUser(id) {
    return api.get(`/api/admin/users/${id}`);
  },

  updateRole(id, roleId) {
    return api.patch(`/api/admin/users/${id}/role`, { roleId });
  },

  deleteUser(id) {
    return api.delete(`/api/admin/users/${id}`);
  },
};
