import api from './axiosInstance';

export const classesApi = {
  getAll() {
    return api.get('/api/classes');
  },

  getById(id) {
    return api.get(`/api/classes/${id}`);
  },

  getSubclasses(id) {
    return api.get(`/api/classes/${id}/subclasses`);
  },

  getSkills(id, subclassId) {
    const qs = subclassId ? `?subclassId=${subclassId}` : '';
    return api.get(`/api/classes/${id}/skills${qs}`);
  },

  getSpells(id, level) {
    const qs = level !== undefined ? `?level=${level}` : '';
    return api.get(`/api/classes/${id}/spells${qs}`);
  },

  getSpellSlots(id) {
    return api.get(`/api/classes/${id}/spellslots`);
  },
};
