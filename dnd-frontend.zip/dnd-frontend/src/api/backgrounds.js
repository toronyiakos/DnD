import api from './axiosInstance';

export const backgroundsApi = {
  getAll() {
    return api.get('/api/backgrounds');
  },

  getById(id) {
    return api.get(`/api/backgrounds/${id}`);
  },
};
