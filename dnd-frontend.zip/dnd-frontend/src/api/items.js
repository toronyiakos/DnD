import api from './axiosInstance';

export const itemsApi = {
  getAll(params = {}) {
    const query = new URLSearchParams();
    if (params.typeId) query.append('typeId', params.typeId);
    if (params.rarityId) query.append('rarityId', params.rarityId);
    if (params.attuned !== undefined) query.append('attuned', params.attuned);
    const qs = query.toString();
    return api.get(`/api/items${qs ? `?${qs}` : ''}`);
  },

  getById(id) {
    return api.get(`/api/items/${id}`);
  },

  create(data) {
    return api.post('/api/items', data);
  },

  update(id, data) {
    return api.put(`/api/items/${id}`, data);
  },

  delete(id) {
    return api.delete(`/api/items/${id}`);
  },
};
