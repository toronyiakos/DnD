import api from './axiosInstance';

export const referenceApi = {
  getAlignments() {
    return api.get('/api/reference/alignments');
  },
  getSizes() {
    return api.get('/api/reference/sizes');
  },
  getMonsterTypes() {
    return api.get('/api/reference/monster-types');
  },
  getItemTypes() {
    return api.get('/api/reference/item-types');
  },
  getItemRarities() {
    return api.get('/api/reference/item-rarities');
  },
  getMetamagic() {
    return api.get('/api/reference/metamagic');
  },
  getFightingStyles() {
    return api.get('/api/reference/fighting-styles');
  },
  getEldritchInvocations() {
    return api.get('/api/reference/eldritch-invocations');
  },
  getWildMagicSurge() {
    return api.get('/api/reference/wild-magic-surge');
  },
  getBattleMasterManeuvers() {
    return api.get('/api/reference/battle-master-maneuvers');
  },
  getDruidFormLimits() {
    return api.get('/api/reference/druid-form-limits');
  },
  getDraconicAncestries() {
    return api.get('/api/reference/draconic-ancestries');
  },
  getLandDruidDomains() {
    return api.get('/api/reference/land-druid-domains');
  },
  getLandDruidDomainSpells(id) {
    return api.get(`/api/reference/land-druid-domains/${id}/spells`);
  },
  getProfByLevel() {
    return api.get('/api/reference/prof-by-level');
  },
  getSorceryPoints() {
    return api.get('/api/reference/sorcery-points');
  },
  getWarlockSpellLevels() {
    return api.get('/api/reference/warlock-spell-levels');
  },
  getWarlockPactBoons() {
    return api.get('/api/reference/warlock-pact-boons');
  },
  getSneakAttack() {
    return api.get('/api/reference/sneak-attack');
  },
};
