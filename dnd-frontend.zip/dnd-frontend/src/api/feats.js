import api from './axiosInstance';

export const featsApi = {
  getAll() {
    return api.get('/api/feats');
  },

  getById(id) {
    return api.get(`/api/feats/${id}`);
  },

  create(data) {
    return api.post('/api/feats', data);
  },

  delete(id) {
    return api.delete(`/api/feats/${id}`);
  },
};
