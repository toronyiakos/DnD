import api from './axiosInstance';

export const racesApi = {
  getAll() {
    return api.get('/api/races');
  },

  getById(id) {
    return api.get(`/api/races/${id}`);
  },

  getSubraces(id) {
    return api.get(`/api/races/${id}/subraces`);
  },

  getRacials(id) {
    return api.get(`/api/races/${id}/racials`);
  },
};
