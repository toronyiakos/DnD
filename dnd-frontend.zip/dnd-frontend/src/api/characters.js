import api from './axiosInstance';

export const charactersApi = {
  getAll() {
    return api.get('/api/characters');
  },

  getById(id) {
    return api.get(`/api/characters/${id}`);
  },

  create(data) {
    return api.post('/api/characters', data);
  },

  update(id, data) {
    return api.patch(`/api/characters/${id}`, data);
  },

  delete(id) {
    return api.delete(`/api/characters/${id}`);
  },

  getInventory(id) {
    return api.get(`/api/characters/${id}/inventory`);
  },

  addItem(characterId, itemId) {
    return api.post(`/api/characters/${characterId}/inventory/${itemId}`);
  },

  removeItem(characterId, itemId) {
    return api.delete(`/api/characters/${characterId}/inventory/${itemId}`);
  },
};
