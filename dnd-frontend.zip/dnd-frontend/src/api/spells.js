import api from './axiosInstance';

export const spellsApi = {
  getAll(params = {}) {
    const query = new URLSearchParams();
    if (params.level !== undefined && params.level !== '') query.append('level', params.level);
    if (params.type) query.append('type', params.type);
    if (params.classId) query.append('classId', params.classId);
    const qs = query.toString();
    return api.get(`/api/spells${qs ? `?${qs}` : ''}`);
  },

  getById(id) {
    return api.get(`/api/spells/${id}`);
  },

  create(data) {
    return api.post('/api/spells', data);
  },

  update(id, data) {
    return api.put(`/api/spells/${id}`, data);
  },

  delete(id) {
    return api.delete(`/api/spells/${id}`);
  },
};
