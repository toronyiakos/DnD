import api from './axiosInstance';

export const monstersApi = {
  getAll(params = {}) {
    const query = new URLSearchParams();
    if (params.name) query.append('name', params.name);
    if (params.typeId) query.append('typeId', params.typeId);
    if (params.sizeId) query.append('sizeId', params.sizeId);
    const qs = query.toString();
    return api.get(`/api/monsters${qs ? `?${qs}` : ''}`);
  },

  getById(id) {
    return api.get(`/api/monsters/${id}`);
  },

  create(data) {
    return api.post('/api/monsters', data);
  },

  update(id, data) {
    return api.put(`/api/monsters/${id}`, data);
  },

  delete(id) {
    return api.delete(`/api/monsters/${id}`);
  },
};
