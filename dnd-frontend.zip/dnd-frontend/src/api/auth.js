import api from './axiosInstance';

export const authApi = {
  register(name, password) {
    return api.post('/api/auth/register', { Name: name, Password: password });
  },

  login(name, password) {
    return api.post('/api/auth/login', { Name: name, Password: password });
  },

  authCheck() {
    return api.get('/api/auth/authcheck');
  },
};
