import axios from 'axios';

// In development, use relative URLs so Vite's proxy handles /api/* requests.
// In production, set VITE_API_BASE_URL to the actual backend URL.
const API_BASE = import.meta.env.VITE_API_BASE_URL || '';

const axiosInstance = axios.create({
  baseURL: API_BASE,
  headers: {
    'Content-Type': 'application/json',
  },
});

// Request interceptor – attach JWT token
axiosInstance.interceptors.request.use(
  (config) => {
    const token = localStorage.getItem('dnd_token');
    if (token) {
      // Check expiration
      const expiresAt = localStorage.getItem('dnd_expires_at');
      if (expiresAt && new Date(expiresAt) < new Date()) {
        localStorage.removeItem('dnd_token');
        localStorage.removeItem('dnd_user');
        localStorage.removeItem('dnd_role');
        localStorage.removeItem('dnd_expires_at');
        window.location.href = '/login';
        return Promise.reject(new Error('Token expired'));
      }
      config.headers.Authorization = `Bearer ${token}`;
    }
    return config;
  },
  (error) => Promise.reject(error)
);

// Response interceptor – handle 401
axiosInstance.interceptors.response.use(
  (response) => response,
  (error) => {
    if (error.response?.status === 401) {
      localStorage.removeItem('dnd_token');
      localStorage.removeItem('dnd_user');
      localStorage.removeItem('dnd_role');
      localStorage.removeItem('dnd_expires_at');
      // Only redirect if not already on login/register pages
      const path = window.location.pathname;
      if (!path.startsWith('/login') && !path.startsWith('/register')) {
        window.location.href = '/login';
      }
    }
    return Promise.reject(error);
  }
);

export default axiosInstance;
